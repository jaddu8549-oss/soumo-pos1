# Testing Report

**Read this first:** this project was authored in a sandbox that has a JDK and Gradle but **no Android SDK and no internet access to download one**. Therefore:

* The **APK has NOT been built**.
* The **Android code (UI, Room, Bluetooth, PDF, backup) has NOT been compiled or run** — not on an emulator, not on a phone, not with a printer.
* Only the pure money/formatting logic was compiled and executed.

Treat everything marked "Not tested" as untested code that may contain compile errors or bugs. Section "How to verify" below is the checklist to run on your phone.

## Executed here (JVM)

`app/src/test/java/com/soumohotel/pos/CalcTest.kt` — compiled with Kotlin 2.0.21 and run with JUnit 4: **9 / 9 passed.**

| Test | Result |
|---|---|
| ₹180 example bill (2×₹40 + 1×₹80 + 2×₹10) | Pass |
| Cash-only and UPI-only resolve to the full total | Pass |
| Split: ₹200 + ₹300 = ₹500 accepted; ₹200+₹200, ₹300+₹300, negative amounts, ₹0 total rejected | Pass |
| Expected closing cash formula | Pass |
| Expected UPI formula | Pass |
| Shortage negative / excess positive / matched zero | Pass |
| Indian grouping and ₹ formatting (12,34,567; ₹1,23,456.50; negatives) | Pass |
| Money parsing without floating-point error (10.10 → 1010 paise; rejects text/negatives) | Pass |
| Business date uses Asia/Kolkata (20:00 UTC → next day) | Pass |

## Not tested (needs a device)

| Requirement from your list | Status |
|---|---|
| Creating food items / updating prices | Not tested |
| Creating bills, multi-item, cash, UPI, split | Logic unit-tested; UI + database path not tested |
| Expense entries | Not tested |
| Daily closing calculations | Formulas unit-tested; screen + database aggregation not tested |
| Bill history & search | Not tested |
| Report generation, PDF, CSV | Not tested |
| Backup and restore | Not tested |
| Restart persistence | Not tested (design: Room/SQLite file in app storage) |
| Airplane mode | Not tested (design: no INTERNET permission, no network code) |
| **Bluetooth printing** (58/80 mm) | Not tested — needs a real printer |
| WhatsApp share | Not tested |

## How to verify (≈30 min)
1. Build (see `BUILD.md`), install, turn on **airplane mode** (then re-enable Bluetooth only), and keep it on throughout.
2. Add 3 items. Edit one price → create a bill before and after; confirm the old bill keeps the old price.
3. Bills: cash ₹180; UPI; split ₹500 = ₹200 + ₹300 (and try ₹200 + ₹200 → must be blocked). Cancel one bill with a reason.
4. Add a cash expense and a UPI expense; add a cash withdrawal and a UPI refund.
5. Daily Closing: confirm expected cash/UPI against a hand calculation; enter exact counts → green; enter ₹50 less → red SHORT ₹50.
6. Reports: today + custom range; export PDF and CSV; open CSV in Excel.
7. Backup → add one more bill → Restore the backup → bill count returns to the earlier number. Force-stop and reopen the app: data still present.
8. Printer: pair, select, test page, print a bill on 58 mm and 80 mm; check line widths and that the cut/feed works.
9. Set a PIN, close/reopen, confirm lock.

## Known limitations / assumptions
* Excel export is CSV (opens in Excel). A true `.xlsx` would need an extra library.
* Reports/closing PDFs are saved to the app's Reports folder and shared via the Android share sheet (no storage permission needed).
* Bluetooth: classic SPP printers only; some printers may need the pairing PIN.
* Item-level sales figures are before bill-level discounts.
* Release APK is signed with the debug key for easy side-loading; create your own keystore before any wider distribution.
