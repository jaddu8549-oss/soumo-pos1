# Soumo POS — User Guide

## First-time setup (5 minutes)
1. **Settings → Business details**: confirm "Soumo Hotel", add address/phone and your thank-you message → *Save details*.
2. **Menu tab → Add item**: name, price, category (8 are pre-made; you can add more), optional photo. Switch an item off when it's finished for the day.
3. **Connect the printer** (below).
4. Optional: **Settings → Set PIN**.
5. **More → Daily Closing → Opening cash**: enter the cash in the drawer at start of day (after the first day it fills itself from the previous closing).

## Connect your Bluetooth printer
1. Switch the printer on. On the phone: *Android Settings → Bluetooth → pair new device* → choose the printer (PIN is usually `0000` or `1234`).
2. In Soumo POS: **More → Settings → Bluetooth printer**.
3. Pick the paper size (**58 mm** or **80 mm**; A4 makes a PDF instead).
4. Tap **Select / change printer** → allow the Bluetooth permission → tap your printer.
5. Tap **Print test page**. If it prints, you're done. Turn on **Print automatically** if you want every saved bill to print by itself.

If printing fails: printer on? paired? within a few metres? not connected to another phone? Bluetooth on? The error message on screen tells you which.

## Making a bill
1. **New Bill** → tap items to add (tap again for more). Use the search box / category chips to find items quickly.
2. **View bill** → change quantities with − / +, remove with the bin, add a **Discount** if needed.
3. Choose payment: **Cash**, **UPI**, or **Cash + UPI**. For split, type the cash amount; UPI fills in the rest. Save is blocked until cash + UPI equals the total (a red message tells you the gap).
4. Optional customer name/phone (the phone is used to open WhatsApp directly).
5. **Save & Print** (or **Save**). On the bill screen you can reprint, share the **PDF**, or send via **WhatsApp**.

## Cancelling a bill
Bills → open the bill → **Cancel this bill** → type a reason. The bill stays in history marked CANCELLED and is removed from the day's sales. Bills can never be deleted.
If you already gave money back to the customer, also record it under **Daily Closing → Other entries → Refund (cash/UPI)** so the drawer balances.

## Expenses
**More → Expenses**: pick category, enter amount, choose Cash or UPI, save. They flow into Daily Closing automatically. A wrong entry is **Voided** (kept in the audit log), not deleted.

## Daily Closing (end of day)
1. **More → Daily Closing.**
2. Check **Opening cash**. Record anything unusual under *Other cash/UPI entries* (money added to the drawer, cash taken out by the owner, refunds).
3. Count the drawer → type **Actual cash counted**. Check your UPI app/bank → type **Actual UPI collection**.
4. A **green** banner means matched; a **red** banner shows exactly how much is **SHORT** or **EXCESS**.
5. **Close day & save.** Use **Closing PDF** or **WhatsApp** to send the report. You can reopen and update a closing later; changes are audit-logged.

## Reports
**More → Reports**: Today / Week / Month / Custom dates. Shows sales, cash vs UPI, expenses, top items, category sales, hour-wise sales, closing differences, refunds and cancellations. **Export PDF** or **Excel / CSV** (the CSV opens in Excel) and share.

## Backup & restore — please read
* The app makes an **automatic backup daily** (last 7 kept) in its Backups folder.
* **Settings → Backup now** makes an extra copy on the phone. That alone does **not** protect you if the phone is lost or reset.
* **Settings → Save backup to another location / device**: save to a USB/SD card, Google Drive, or send to another phone. **Do this at least weekly.**
* **Restore**: Settings → *Restore from a backup file* (or *on-phone backups*). Your current data is saved first as `before_restore_…`, so a wrong restore can be undone. The app closes after a restore; reopen it.
* Uninstalling the app deletes its data and on-phone backups. Keep an off-phone copy before reinstalling.

## Tips
* Changing a price never changes old bills.
* Removing a menu item only hides it; old bills still show it.
* All times are Indian time (IST) and amounts in ₹ with Indian number grouping (₹1,23,456).
