# Soumo POS — Architecture & Database

Offline restaurant billing for Soumo Hotel. Native Android: Kotlin, Jetpack Compose, Room (SQLite).
**The app declares no INTERNET permission**, so it cannot go online even by accident.

## Layers

```
ui/ (Compose screens)  →  AppViewModel  →  Repository  →  Room DAO  →  SQLite file soumo_pos.db
                              │                │
                              │                └─ db.withTransaction { } for every money write
                              ├─ print/  Receipt (lines) → ESC/POS bytes → BtPrinter (Bluetooth SPP)
                              │                          → Pdfs (A4 / 58 mm / 80 mm PDF)
                              └─ util/   Calc (pure money logic), Fmt (₹, IST), AppPrefs (settings, PIN), Backup, Share
```

* **Money is stored as `Long` paise** (₹1 = 100). No floating point anywhere in calculations.
* **Business date** = `yyyy-MM-dd` in Asia/Kolkata, stored on each record, so "today" and daily closing are exact regardless of phone timezone.
* **Live screens**: `Repository.observe(...)` re-runs a query whenever the relevant tables change, so dashboard/closing update instantly after each bill.
* **Calc.kt has no Android dependencies**, so the money rules are unit-tested on a plain JVM.

## Database (9 tables)

| Table | Purpose | Key fields |
|---|---|---|
| `categories` | Menu categories (8 seeded: Breakfast, Lunch, Dinner, Rolls, Paratha, Snacks, Beverages, Special Items) | name (unique) |
| `food_items` | Menu | name, categoryId, price, available, active (soft delete), imagePath |
| `bills` | Bill header | billNo (unique), createdAt, businessDate, subtotal, discount, total, cashPaid, upiPaid, paymentMode, paymentStatus, customer*, status, cancelReason, cancelledAt |
| `bill_items` | **Snapshot** lines | billId, name, categoryName, qty, rate, total (copied at billing time) |
| `expenses` | Expenses | name, amount, method (CASH/UPI), category, remarks, createdAt, voided |
| `cash_entries` | Other receipts/withdrawals/refunds | type (CASH_IN, CASH_WITHDRAWAL, UPI_IN, REFUND_CASH, REFUND_UPI), amount, note, voided |
| `day_opening` | Opening cash per day | businessDate, openingCash |
| `daily_closing` | Saved reconciliation | expected/actual/diff for cash and UPI, totals, notes |
| `audit_log` | Who-did-what trail | action, entity, entityId, details, createdAt |

### How the data-protection requirements are met

| Requirement | Mechanism |
|---|---|
| Prices changeable without touching old bills | `bill_items` stores name/rate/total copies; editing `food_items.price` never alters them. Price edits are audit-logged (old → new). |
| Never silently delete financial records | No DELETE on bills/expenses/entries. Bills are *cancelled* (reason required, `cancelledAt`, audit). Expenses/entries are *voided*. Menu items are soft-deleted. |
| No incomplete/corrupt bills | Bill + items + audit row written in one `withTransaction`; failure rolls back everything. |
| Unique bill numbers | `SH-yymmdd-0001`; sequence counts cancelled bills too; `billNo` has a unique index. |
| Payment correctness | `Calc.resolvePayment` rejects any bill where cash + UPI ≠ total; the Save button stays disabled and the reason is shown. Bills can only be saved as PAID. |
| Audit log | Bill created/cancelled, price/item edits, expense/entry add/void, refunds, opening cash, day closed/updated, PIN set/removed. |
| Backup | TRUNCATE journal mode ⇒ DB is one file ⇒ clean copy. Manual, automatic daily (keeps 7), and "save to another location" (SAF: SD card, USB, Drive, other device). |
| Safe restore | File validated (SQLite header, `integrity_check`, required tables) → current DB auto-saved as `before_restore_*.db` → replaced → app restarts. |
| PIN | Optional, salted SHA-256, stored on device only. |

## Daily closing formulas

```
Expected Cash = Opening + Cash Sales + Other Cash Received − Cash Expenses − Cash Withdrawals − Cash Refunds
Expected UPI  = UPI Sales + Other UPI Received − UPI Refunds − Expenses paid by UPI
Difference    = Actual − Expected      (negative = SHORT, positive = EXCESS, 0 = matched)
```
Two small additions to your formulas, deliberately: **cash refunds** reduce drawer cash, and **expenses paid via UPI** leave the UPI account. Without them, the reconciliation would show false mismatches. Opening cash defaults to the previous closing's counted cash and can be overridden.
Cancelled bills are excluded from sales. Discount is applied on the whole bill (item-level sales figures are pre-discount).

## Bluetooth printing

* Classic Bluetooth **SPP/RFCOMM** (UUID 00001101…), the protocol almost all 58 mm / 80 mm ESC/POS thermal printers use.
* Pair once in Android Settings → Bluetooth, then pick it in **Settings → Bluetooth printer** (lists paired devices, no scanning needed).
* Permissions: `BLUETOOTH_CONNECT` (Android 12+, asked at runtime); legacy `BLUETOOTH`/`BLUETOOTH_ADMIN` for Android ≤ 11.
* Receipt is built once as styled lines (`Receipt.lines`) and rendered to ESC/POS bytes (58 mm = 32 chars, 80 mm = 48 chars) or to a PDF.
* Text is plain ASCII with "Rs." (most thermal printers cannot print ₹).
* Sends in 512-byte chunks, waits before closing (prevents cut-off prints), falls back to RFCOMM channel 1 for printers that reject the standard connect.
* Limitation: **BLE-only** printers (rare) are not supported; the vast majority sold in India are classic SPP.

## Screens
Bottom bar: Home · New Bill · Menu · Bills · More. More → Expenses, Daily Closing, Reports, Settings (printer, PIN, backup, audit log).
