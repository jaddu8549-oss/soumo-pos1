# Get the APK without Android Studio (free, ~10 minutes, from a computer or phone browser)
1. Create a free account at github.com.
2. Click "+" (top right) > New repository. Name: soumo-pos. Create it.
3. On the new repo page click "uploading an existing file". Unzip SoumoPOS_source.zip first and drag in
   EVERYTHING inside the SoumoPOS folder (including the hidden .github folder). Click Commit changes.
   (If .github does not upload: Add file > Create new file, type  .github/workflows/build.yml  and paste the contents of that file.)
4. Open the "Actions" tab. "Build APK" starts by itself (takes ~5-10 min). Wait for the green tick.
5. Click the finished run > scroll to "Artifacts" > download SoumoPOS-apk (zip). Unzip to get app-debug.apk.
6. Copy the APK to the phone and install (allow "install unknown apps").
If the run shows a red X, open it and send me the error text.
