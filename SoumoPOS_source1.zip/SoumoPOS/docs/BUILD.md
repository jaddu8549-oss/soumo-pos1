# Building the APK

## Option A — Android Studio (easiest)
1. Install **Android Studio** (Koala 2024.1 or newer). Install the Android SDK **API 34** when prompted.
2. *File → Open* → select the `SoumoPOS` folder. Let Gradle sync (needs internet **once**, to download libraries; the finished app itself is fully offline).
3. *Build → Build Bundle(s)/APK(s) → Build APK(s)*.
4. APK appears at `app/build/outputs/apk/debug/app-debug.apk`. Copy it to the phone and install (allow "install unknown apps").

## Option B — command line
```
export ANDROID_HOME=/path/to/Android/sdk     # contains platforms/android-34 and build-tools
./gradlew assembleDebug                      # → app/build/outputs/apk/debug/app-debug.apk
./gradlew assembleRelease                    # → app/build/outputs/apk/release/app-release.apk (debug-signed)
./gradlew testDebugUnitTest                  # runs CalcTest
```
JDK 17+ required.

## If the first build shows errors
This code was written without being compiled (no Android SDK was available where it was authored). Small compile errors are possible. Paste the exact error text back and it can be fixed quickly.

## Install on the phone
Android 8.0 (API 26) or newer. Open the APK → Install. First launch: allow Bluetooth permission when you select a printer.
