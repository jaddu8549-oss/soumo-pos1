package com.soumohotel.pos

import com.soumohotel.pos.util.Calc
import com.soumohotel.pos.util.CartLine
import com.soumohotel.pos.util.Fmt
import com.soumohotel.pos.util.Mode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CalcTest {
    private val sample = listOf(
        CartLine(1, "Egg Roll", "Rolls", 4000, 2),
        CartLine(2, "Chicken Roll", "Rolls", 8000, 1),
        CartLine(3, "Tea", "Beverages", 1000, 2),
    )

    @Test fun billTotalMatchesSpecExample() = assertEquals(18000L, Calc.subtotal(sample)) // ₹180

    @Test fun cashAndUpiPayAllInOne() {
        assertEquals(500_00L to 0L, Calc.resolvePayment(500_00, Mode.CASH, 0, 0).getOrThrow())
        assertEquals(0L to 500_00L, Calc.resolvePayment(500_00, Mode.UPI, 0, 0).getOrThrow())
    }

    @Test fun splitMustEqualTotal() {
        assertEquals(200_00L to 300_00L, Calc.resolvePayment(500_00, Mode.SPLIT, 200_00, 300_00).getOrThrow())
        assertTrue(Calc.resolvePayment(500_00, Mode.SPLIT, 200_00, 200_00).isFailure)
        assertTrue(Calc.resolvePayment(500_00, Mode.SPLIT, 300_00, 300_00).isFailure)
        assertTrue(Calc.resolvePayment(500_00, Mode.SPLIT, -100_00, 600_00).isFailure)
        assertTrue(Calc.resolvePayment(0, Mode.CASH, 0, 0).isFailure)
    }

    @Test fun expectedClosingCashFormula() {
        // Opening 1000 + sales 5000 + other 200 - expenses 700 - withdrawals 500 - refunds 50
        assertEquals(
            100_000L + 500_000L + 20_000L - 70_000L - 50_000L - 5_000L,
            Calc.expectedCash(100_000, 500_000, 20_000, 70_000, 50_000, 5_000),
        )
    }

    @Test fun expectedUpi() = assertEquals(300_000L + 10_000L - 5_000L - 20_000L, Calc.expectedUpi(300_000, 10_000, 5_000, 20_000))

    @Test fun shortageIsNegativeExcessPositive() {
        assertEquals(-500L, Calc.diff(9_500, 10_000))
        assertEquals(500L, Calc.diff(10_500, 10_000))
        assertEquals(0L, Calc.diff(10_000, 10_000))
    }

    @Test fun indianGroupingAndRupees() {
        assertEquals("12,34,567", Fmt.indian(1234567))
        assertEquals("₹180", Fmt.rupees(18000))
        assertEquals("₹1,23,456.50", Fmt.rupees(12345650))
        assertEquals("-₹40", Fmt.rupees(-4000))
        assertEquals("80.00", Fmt.plain(8000))
    }

    @Test fun moneyParsingHasNoFloatingPointError() {
        assertEquals(1010L, Fmt.parseMoney("10.10"))
        assertEquals(1999L, Fmt.parseMoney("19.99"))
        assertEquals(30L, Fmt.parseMoney("0.3"))
        assertNull(Fmt.parseMoney("abc"))
        assertNull(Fmt.parseMoney("-5"))
        assertNull(Fmt.parseMoney(""))
    }

    @Test fun businessDateUsesIndiaTimezone() {
        // 2026-11-15 20:00 UTC is already 16 Nov 01:30 in Kolkata
        val ms = java.time.ZonedDateTime.of(2026, 11, 15, 20, 0, 0, 0, java.time.ZoneOffset.UTC).toInstant().toEpochMilli()
        assertEquals("2026-11-16", Fmt.businessDate(ms))
    }
}
