@file:OptIn(ExperimentalLayoutApi::class)

package com.soumohotel.pos.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.soumohotel.pos.AppViewModel
import com.soumohotel.pos.data.EntryType
import com.soumohotel.pos.util.Fmt

@Composable
fun ClosingScreen(vm: AppViewModel, nav: NavController) {
    var date by remember { mutableStateOf(Fmt.today()) }
    val f by remember(date) { vm.repo.observeDay(date) }.collectAsState(null)
    val entries by remember(date) { vm.repo.observeEntries(date) }.collectAsState(emptyList())
    val d = f
    var openTxt by remember(date, d?.opening) { mutableStateOf(d?.let { Fmt.input(it.opening) } ?: "") }
    var cashTxt by remember(date, d?.closing?.closedAt) { mutableStateOf(d?.closing?.actualCash?.let { Fmt.input(it).ifEmpty { "0" } } ?: "") }
    var upiTxt by remember(date, d?.closing?.closedAt) { mutableStateOf(d?.closing?.actualUpi?.let { Fmt.input(it).ifEmpty { "0" } } ?: "") }
    var notes by remember(date, d?.closing?.closedAt) { mutableStateOf(d?.closing?.notes ?: "") }
    var entryType by remember { mutableStateOf<String?>(null) }

    Page("Daily Closing", onBack = { nav.popBackStack() }) {
        Body {
            DateField("Date", date, { date = it })
            if (d == null) { Text("Loading…"); return@Body }

            SectionTitle("Opening cash")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                MoneyField("Opening cash", openTxt, { openTxt = it }, Modifier.weight(1f))
                FilledTonalButton({ vm.setOpening(date, Fmt.parseMoney(openTxt) ?: 0L) }) { Text("Set") }
            }
            Text("Defaults to the previous day's counted cash.", fontSize = 12.sp)

            SectionTitle("Cash reconciliation")
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    RowKV("Opening cash", Fmt.rupees(d.opening))
                    RowKV("+ Cash sales", Fmt.rupees(d.cashSales))
                    RowKV("+ Other cash received", Fmt.rupees(d.otherCashIn))
                    RowKV("− Cash expenses", Fmt.rupees(d.cashExpenses))
                    RowKV("− Cash withdrawals", Fmt.rupees(d.withdrawals))
                    RowKV("− Cash refunds", Fmt.rupees(d.cashRefunds))
                    RowKV("Expected closing cash", Fmt.rupees(d.expectedCash), bold = true)
                }
            }
            MoneyField("Actual cash counted", cashTxt, { cashTxt = it }, Modifier.fillMaxWidth())
            val actualCash = Fmt.parseMoney(cashTxt)
            DiffBanner("Cash", actualCash, d.expectedCash)

            SectionTitle("UPI reconciliation")
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    RowKV("UPI sales", Fmt.rupees(d.upiSales))
                    RowKV("+ Other UPI receipts", Fmt.rupees(d.otherUpiIn))
                    RowKV("− UPI refunds", Fmt.rupees(d.upiRefunds))
                    RowKV("− Expenses paid by UPI", Fmt.rupees(d.upiExpenses))
                    RowKV("Expected UPI collection", Fmt.rupees(d.expectedUpi), bold = true)
                }
            }
            MoneyField("Actual UPI collection", upiTxt, { upiTxt = it }, Modifier.fillMaxWidth())
            val actualUpi = Fmt.parseMoney(upiTxt)
            DiffBanner("UPI", actualUpi, d.expectedUpi)

            SectionTitle("Summary")
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    RowKV("Total sales", Fmt.rupees(d.totalSales), bold = true)
                    RowKV("Cash collection", Fmt.rupees(d.cashSales))
                    RowKV("UPI collection", Fmt.rupees(d.upiSales))
                    RowKV("Total expenses", Fmt.rupees(d.totalExpenses))
                    RowKV("Total refunds", Fmt.rupees(d.totalRefunds))
                    RowKV("Total bills", d.bills.toString())
                    RowKV("Cancelled bills", "${d.cancelledCount} (${Fmt.rupees(d.cancelledAmount)})")
                    RowKV("Cash difference", actualCash?.let { signed(it - d.expectedCash) } ?: "—")
                    RowKV("UPI difference", actualUpi?.let { signed(it - d.expectedUpi) } ?: "—")
                }
            }
            TextField1("Notes (optional)", notes, { notes = it }, Modifier.fillMaxWidth())
            Button(
                onClick = {
                    if (actualCash == null || actualUpi == null) vm.toast("Enter actual cash and actual UPI (use 0 if none)")
                    else vm.closeDay(date, actualCash, actualUpi, notes)
                },
                modifier = Modifier.fillMaxWidth().height(56.dp),
            ) { Text(if (d.closing == null) "Close day & save" else "Update closing", fontSize = 16.sp) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton({ vm.shareClosingPdf(date, actualCash ?: 0, actualUpi ?: 0, false) }, Modifier.weight(1f)) { Text("Closing PDF") }
                OutlinedButton({ vm.shareClosingPdf(date, actualCash ?: 0, actualUpi ?: 0, true) }, Modifier.weight(1f)) { Text("WhatsApp") }
            }

            SectionTitle("Other cash / UPI entries")
            Text("Record money that is not a sale or expense. These feed the reconciliation above.", fontSize = 12.sp)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(EntryType.CASH_IN, EntryType.CASH_WITHDRAWAL, EntryType.UPI_IN, EntryType.REFUND_CASH, EntryType.REFUND_UPI).forEach {
                    FilledTonalButton({ entryType = it }) { Text(EntryType.label(it)) }
                }
            }
            entries.forEach { e ->
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = if (e.voided) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface)) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(EntryType.label(e.type) + if (e.voided) " (VOIDED)" else "", fontWeight = FontWeight.SemiBold)
                            Text(Fmt.dateTime(e.createdAt) + (e.note?.let { " · $it" } ?: ""), fontSize = 12.sp)
                        }
                        Text(Fmt.rupees(e.amount), fontWeight = FontWeight.Bold)
                        if (!e.voided) TextButton({ vm.voidEntry(e.id) }) { Text("Void", color = Red) }
                    }
                }
            }
        }
    }

    entryType?.let { t ->
        var amt by remember { mutableStateOf("") }
        var note by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { entryType = null },
            title = { Text(EntryType.label(t)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    MoneyField("Amount", amt, { amt = it })
                    TextField1("Note (optional)", note, { note = it })
                }
            },
            confirmButton = {
                TextButton({
                    val a = Fmt.parseMoney(amt)
                    if (a == null || a <= 0) vm.toast("Enter a valid amount") else vm.addEntry(t, a, note) { entryType = null }
                }) { Text("Save") }
            },
            dismissButton = { TextButton({ entryType = null }) { Text("Cancel") } },
        )
    }
}

private fun signed(diff: Long) = when {
    diff == 0L -> "Matched ✔"
    diff < 0 -> "SHORT ${Fmt.rupees(-diff)}"
    else -> "EXCESS ${Fmt.rupees(diff)}"
}

/** Green when matched, red when there is a shortage or excess. */
@Composable
private fun DiffBanner(label: String, actual: Long?, expected: Long) {
    if (actual == null) return
    val diff = actual - expected
    val ok = diff == 0L
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (ok) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.errorContainer,
        ),
    ) {
        Text(
            if (ok) "$label matched ✔" else "$label MISMATCH — " + signed(diff),
            Modifier.padding(14.dp), fontWeight = FontWeight.Bold, fontSize = 16.sp,
            color = if (ok) Green else Red,
        )
    }
}
