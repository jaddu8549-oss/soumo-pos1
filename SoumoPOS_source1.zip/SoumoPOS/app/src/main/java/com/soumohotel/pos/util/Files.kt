package com.soumohotel.pos.util

import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import androidx.core.content.FileProvider
import com.soumohotel.pos.data.PosDatabase
import java.io.File

object Share {
    fun uri(ctx: Context, f: File): Uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)

    /** Opens the share sheet. With [whatsapp] it goes straight to WhatsApp if installed. */
    fun file(ctx: Context, f: File, mime: String, whatsapp: Boolean = false, phone: String? = null) {
        val u = uri(ctx, f)
        val base = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, u)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        if (whatsapp) {
            val digits = phone?.filter { it.isDigit() }?.takeLast(10)
            for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
                val i = Intent(base).setPackage(pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                if (digits?.length == 10) i.putExtra("jid", "91$digits@s.whatsapp.net")
                if (runCatching { ctx.startActivity(i) }.isSuccess) return
            }
        }
        ctx.startActivity(Intent.createChooser(base, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

object Backup {
    fun dbFile(ctx: Context): File = ctx.getDatabasePath(PosDatabase.NAME)

    fun backupDir(ctx: Context): File =
        File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "Backups").also { it.mkdirs() }

    fun reportDir(ctx: Context): File =
        File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "Reports").also { it.mkdirs() }

    private fun stamp() = java.time.ZonedDateTime.now(Fmt.IST)
        .format(java.time.format.DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"))

    /** Copies the live database into the app's backup folder on phone storage. */
    fun createLocal(ctx: Context, prefix: String = "soumo_backup"): File {
        val dest = File(backupDir(ctx), "${prefix}_${stamp()}.db")
        dbFile(ctx).copyTo(dest, overwrite = true)
        return dest
    }

    /** Auto backup once per day; keeps the newest 7. */
    fun autoDaily(ctx: Context, prefs: AppPrefs) {
        val today = Fmt.today()
        if (prefs.lastAutoBackup == today || !dbFile(ctx).exists()) return
        runCatching {
            createLocal(ctx, "auto")
            backupDir(ctx).listFiles { f -> f.name.startsWith("auto_") }?.sortedByDescending { it.name }?.drop(7)?.forEach { it.delete() }
            prefs.lastAutoBackup = today
        }
    }

    fun exportTo(ctx: Context, target: Uri) {
        ctx.contentResolver.openOutputStream(target, "w")!!.use { out -> dbFile(ctx).inputStream().use { it.copyTo(out) } }
    }

    /** A file is accepted only if it is a real SQLite database containing our tables and passes integrity_check. */
    fun isValid(f: File): Boolean = runCatching {
        val db = SQLiteDatabase.openDatabase(f.path, null, SQLiteDatabase.OPEN_READONLY)
        db.use {
            val ok = it.rawQuery("PRAGMA integrity_check", null).use { c -> c.moveToFirst() && c.getString(0) == "ok" }
            val hasTables = it.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name IN ('bills','bill_items','food_items')", null)
                .use { c -> c.count == 3 }
            ok && hasTables
        }
    }.getOrDefault(false)

    /**
     * Restores a backup. The current database is first saved as "before_restore_*.db" so nothing
     * can be lost by a wrong restore. The app must be restarted afterwards.
     */
    fun restore(ctx: Context, source: Uri): Result<Unit> = runCatching {
        val tmp = File(ctx.cacheDir, "restore_candidate.db")
        ctx.contentResolver.openInputStream(source)!!.use { i -> tmp.outputStream().use { i.copyTo(it) } }
        check(isValid(tmp)) { "This file is not a valid Soumo POS backup." }
        createLocal(ctx, "before_restore")
        PosDatabase.closeAndReset()
        val live = dbFile(ctx)
        listOf("-wal", "-shm", "-journal").forEach { File(live.path + it).delete() }
        tmp.copyTo(live, overwrite = true)
        tmp.delete()
    }
}
