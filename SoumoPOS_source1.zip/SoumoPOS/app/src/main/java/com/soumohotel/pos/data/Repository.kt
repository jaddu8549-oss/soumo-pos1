package com.soumohotel.pos.data

import android.content.Context
import androidx.room.InvalidationTracker
import androidx.room.withTransaction
import com.soumohotel.pos.util.Calc
import com.soumohotel.pos.util.CartLine
import com.soumohotel.pos.util.Fmt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map

/** Everything needed for the Dashboard and Daily Closing screens for one business day. */
data class DayFigures(
    val date: String,
    val bills: Int,
    val totalSales: Long,
    val cashSales: Long,
    val upiSales: Long,
    val discount: Long,
    val cancelledCount: Int,
    val cancelledAmount: Long,
    val cashExpenses: Long,
    val upiExpenses: Long,
    val otherCashIn: Long,
    val otherUpiIn: Long,
    val withdrawals: Long,
    val cashRefunds: Long,
    val upiRefunds: Long,
    val opening: Long,
    val expectedCash: Long,
    val expectedUpi: Long,
    val closing: DailyClosing?,
) {
    val avgBill: Long get() = if (bills == 0) 0 else totalSales / bills
    val totalExpenses: Long get() = cashExpenses + upiExpenses
    val totalRefunds: Long get() = cashRefunds + upiRefunds
}

data class RangeReport(
    val from: String,
    val to: String,
    val summary: SalesSummary,
    val cancelled: CancelSummary,
    val cashExpenses: Long,
    val upiExpenses: Long,
    val cashRefunds: Long,
    val upiRefunds: Long,
    val topItems: List<NameAmt>,
    val categories: List<NameAmt>,
    val hours: List<HourAmt>,
    val closings: List<DailyClosing>,
) {
    val totalExpenses get() = cashExpenses + upiExpenses
    val totalRefunds get() = cashRefunds + upiRefunds
    val avgBill get() = if (summary.bills == 0) 0L else summary.total / summary.bills
}

object EntryType {
    const val CASH_IN = "CASH_IN"
    const val CASH_WITHDRAWAL = "CASH_WITHDRAWAL"
    const val UPI_IN = "UPI_IN"
    const val REFUND_CASH = "REFUND_CASH"
    const val REFUND_UPI = "REFUND_UPI"
    fun label(t: String) = when (t) {
        CASH_IN -> "Cash received"
        CASH_WITHDRAWAL -> "Cash withdrawn"
        UPI_IN -> "UPI received"
        REFUND_CASH -> "Refund (cash)"
        REFUND_UPI -> "Refund (UPI)"
        else -> t
    }
}

class Repository(context: Context) {
    val db: PosDatabase = PosDatabase.get(context)
    val dao: PosDao = db.dao()

    private fun List<TypeTotal>.of(t: String) = firstOrNull { it.type == t }?.amount ?: 0L
    private fun List<MethodTotal>.of(m: String) = firstOrNull { it.method == m }?.amount ?: 0L

    /** Re-runs [block] every time one of [tables] changes, so screens always show live numbers. */
    private fun <T> observe(vararg tables: String, block: suspend () -> T): Flow<T> =
        callbackFlow<Unit> {
            val obs = object : InvalidationTracker.Observer(arrayOf(*tables)) {
                override fun onInvalidated(t: Set<String>) {
                    trySend(Unit)
                }
            }
            db.invalidationTracker.addObserver(obs)
            trySend(Unit)
            awaitClose { db.invalidationTracker.removeObserver(obs) }
        }.conflate().map { block() }.flowOn(Dispatchers.IO)

    private suspend fun audit(action: String, entity: String, id: Any, details: String) =
        dao.insertAudit(AuditLog(action = action, entity = entity, entityId = id.toString(), details = details))

    // ===================== Menu =====================
    suspend fun addCategory(name: String): Result<Unit> = runCatching {
        require(name.isNotBlank()) { "Category name is empty" }
        dao.insertCategory(Category(name = name.trim(), sortOrder = 100))
        Unit
    }

    suspend fun saveFood(existing: FoodItem?, name: String, categoryId: Long, price: Long, available: Boolean, imagePath: String?): Result<Unit> =
        runCatching {
            require(name.isNotBlank()) { "Item name is empty" }
            require(price > 0) { "Price must be more than ₹0" }
            db.withTransaction {
                if (existing == null) {
                    val id = dao.insertFood(FoodItem(name = name.trim(), categoryId = categoryId, price = price, available = available, imagePath = imagePath))
                    audit("ITEM_CREATED", "food_item", id, "${name.trim()} @ ${Fmt.rupees(price)}")
                } else {
                    dao.updateFood(existing.copy(name = name.trim(), categoryId = categoryId, price = price, available = available, imagePath = imagePath))
                    if (existing.price != price)
                        audit("PRICE_CHANGED", "food_item", existing.id, "${existing.name}: ${Fmt.rupees(existing.price)} -> ${Fmt.rupees(price)}")
                    else
                        audit("ITEM_EDITED", "food_item", existing.id, name.trim())
                }
            }
        }

    suspend fun setAvailable(f: FoodItem, available: Boolean) {
        dao.updateFood(f.copy(available = available))
        audit("ITEM_AVAILABILITY", "food_item", f.id, "${f.name} -> ${if (available) "on" else "off"}")
    }

    suspend fun deactivateFood(f: FoodItem) {
        dao.updateFood(f.copy(active = false, available = false))
        audit("ITEM_DELETED", "food_item", f.id, "${f.name} (hidden; old bills unchanged)")
    }

    // ===================== Billing =====================
    suspend fun createBill(
        lines: List<CartLine>, discount: Long, mode: String, cash: Long, upi: Long,
        customerName: String?, customerPhone: String?,
    ): Result<Long> = runCatching {
        require(lines.isNotEmpty()) { "Add at least one item" }
        require(lines.all { it.qty > 0 && it.rate > 0 }) { "Invalid quantity or rate" }
        val sub = Calc.subtotal(lines)
        require(discount in 0..sub) { "Discount cannot be more than the subtotal" }
        val total = sub - discount
        val (c, u) = Calc.resolvePayment(total, mode, cash, upi).getOrThrow()

        // One transaction: the bill, its items and the audit entry are saved together or not at all.
        db.withTransaction {
            val now = System.currentTimeMillis()
            val bd = Fmt.businessDate(now)
            val seq = dao.billCountForDate(bd) + 1 // cancelled bills still count, so numbers never repeat
            val no = "SH-" + bd.replace("-", "").drop(2) + "-" + seq.toString().padStart(4, '0')
            val id = dao.insertBill(
                Bill(
                    billNo = no, createdAt = now, businessDate = bd, subtotal = sub, discount = discount,
                    total = total, cashPaid = c, upiPaid = u, paymentMode = mode, paymentStatus = "PAID",
                    customerName = customerName?.trim()?.ifBlank { null },
                    customerPhone = customerPhone?.trim()?.ifBlank { null },
                )
            )
            dao.insertBillItems(lines.map {
                BillItem(billId = id, foodItemId = it.foodId, name = it.name, categoryName = it.category, qty = it.qty, rate = it.rate, total = it.total)
            })
            audit("BILL_CREATED", "bill", id, "$no total ${Fmt.rupees(total)} cash ${Fmt.rupees(c)} upi ${Fmt.rupees(u)}")
            id
        }
    }

    suspend fun cancelBill(id: Long, reason: String): Result<Unit> = runCatching {
        require(reason.isNotBlank()) { "A cancellation reason is required" }
        db.withTransaction {
            val b = dao.bill(id) ?: error("Bill not found")
            check(b.status == "ACTIVE") { "Bill is already cancelled" }
            dao.cancelBill(id, reason.trim(), System.currentTimeMillis())
            audit("BILL_CANCELLED", "bill", id, "${b.billNo} ${Fmt.rupees(b.total)} — ${reason.trim()}")
        }
    }

    suspend fun billWithItems(id: Long): Pair<Bill, List<BillItem>>? {
        val b = dao.bill(id) ?: return null
        return b to dao.billItems(id)
    }

    fun observeBill(id: Long) = observe("bills", "bill_items") { billWithItems(id) }

    fun observeBills(query: String): Flow<List<Bill>> = observe("bills") {
        val q = query.trim()
        if (q.isEmpty()) dao.recentBills() else dao.searchBills(q, Fmt.parseUserDate(q) ?: q)
    }

    // ===================== Expenses & other entries =====================
    suspend fun addExpense(name: String, amount: Long, method: String, category: String, remarks: String?): Result<Unit> = runCatching {
        require(name.isNotBlank()) { "Expense name is empty" }
        require(amount > 0) { "Amount must be more than ₹0" }
        db.withTransaction {
            val now = System.currentTimeMillis()
            val id = dao.insertExpense(
                Expense(name = name.trim(), amount = amount, method = method, category = category,
                    remarks = remarks?.trim()?.ifBlank { null }, createdAt = now, businessDate = Fmt.businessDate(now))
            )
            audit("EXPENSE_ADDED", "expense", id, "${name.trim()} ${Fmt.rupees(amount)} ($method)")
        }
    }

    suspend fun voidExpense(id: Long) = db.withTransaction {
        val e = dao.expense(id)
        dao.voidExpense(id)
        audit("EXPENSE_VOIDED", "expense", id, "${e?.name} ${e?.let { Fmt.rupees(it.amount) }}")
    }

    fun observeExpenses(date: String) = observe("expenses") { dao.expensesBetween(date, date) }

    suspend fun addEntry(type: String, amount: Long, note: String?): Result<Unit> = runCatching {
        require(amount > 0) { "Amount must be more than ₹0" }
        db.withTransaction {
            val now = System.currentTimeMillis()
            val id = dao.insertEntry(CashEntry(type = type, amount = amount, note = note?.trim()?.ifBlank { null }, createdAt = now, businessDate = Fmt.businessDate(now)))
            audit(if (type.startsWith("REFUND")) "REFUND_RECORDED" else "ENTRY_ADDED", "cash_entry", id, "${EntryType.label(type)} ${Fmt.rupees(amount)} ${note ?: ""}")
        }
    }

    suspend fun voidEntry(id: Long) = db.withTransaction {
        val e = dao.entry(id)
        dao.voidEntry(id)
        audit("ENTRY_VOIDED", "cash_entry", id, "${e?.type} ${e?.let { Fmt.rupees(it.amount) }}")
    }

    fun observeEntries(date: String) = observe("cash_entries") { dao.entriesBetween(date, date) }

    // ===================== Day figures & closing =====================
    suspend fun dayFigures(date: String): DayFigures {
        val s = dao.summary(date, date)
        val c = dao.cancelSummary(date, date)
        val exp = dao.expenseTotals(date, date)
        val ent = dao.entryTotals(date, date)
        val opening = dao.opening(date)?.openingCash ?: dao.lastClosingBefore(date)?.actualCash ?: 0L
        val cashExp = exp.of("CASH")
        val upiExp = exp.of("UPI")
        val expCash = Calc.expectedCash(opening, s.cash, ent.of(EntryType.CASH_IN), cashExp, ent.of(EntryType.CASH_WITHDRAWAL), ent.of(EntryType.REFUND_CASH))
        val expUpi = Calc.expectedUpi(s.upi, ent.of(EntryType.UPI_IN), ent.of(EntryType.REFUND_UPI), upiExp)
        return DayFigures(
            date = date, bills = s.bills, totalSales = s.total, cashSales = s.cash, upiSales = s.upi, discount = s.discount,
            cancelledCount = c.count, cancelledAmount = c.amount, cashExpenses = cashExp, upiExpenses = upiExp,
            otherCashIn = ent.of(EntryType.CASH_IN), otherUpiIn = ent.of(EntryType.UPI_IN),
            withdrawals = ent.of(EntryType.CASH_WITHDRAWAL), cashRefunds = ent.of(EntryType.REFUND_CASH),
            upiRefunds = ent.of(EntryType.REFUND_UPI), opening = opening, expectedCash = expCash, expectedUpi = expUpi,
            closing = dao.closing(date),
        )
    }

    fun observeDay(date: String) =
        observe("bills", "expenses", "cash_entries", "day_opening", "daily_closing") { dayFigures(date) }

    fun observeHours(date: String) = observe("bills") { dao.hourSales(date, date) }

    /** Last [n] days of sales (oldest first), with zero-filled gaps. Name = dd/MM. */
    fun observeLastDays(n: Int) = observe("bills") {
        val to = Fmt.todayDate()
        val from = to.minusDays((n - 1).toLong())
        val map = dao.dailySales(from.toString(), to.toString()).associateBy { it.name }
        (0 until n).map { i ->
            val d = from.plusDays(i.toLong())
            val row = map[d.toString()]
            NameAmt("%02d/%02d".format(d.dayOfMonth, d.monthValue), row?.qty ?: 0, row?.amount ?: 0)
        }
    }

    suspend fun setOpening(date: String, amount: Long) {
        db.withTransaction {
            dao.upsertOpening(DayOpening(date, amount))
            audit("OPENING_SET", "day_opening", date, "Opening cash ${Fmt.rupees(amount)}")
        }
    }

    suspend fun closeDay(date: String, actualCash: Long, actualUpi: Long, notes: String?): Result<DailyClosing> = runCatching {
        require(actualCash >= 0 && actualUpi >= 0) { "Enter the actual cash and UPI amounts" }
        db.withTransaction {
            val f = dayFigures(date)
            val prev = dao.closing(date)
            val c = DailyClosing(
                businessDate = date, openingCash = f.opening,
                expectedCash = f.expectedCash, actualCash = actualCash, cashDiff = Calc.diff(actualCash, f.expectedCash),
                expectedUpi = f.expectedUpi, actualUpi = actualUpi, upiDiff = Calc.diff(actualUpi, f.expectedUpi),
                totalSales = f.totalSales, totalBills = f.bills, totalExpenses = f.totalExpenses, totalRefunds = f.totalRefunds,
                notes = notes?.trim()?.ifBlank { null }, closedAt = System.currentTimeMillis(),
            )
            dao.upsertClosing(c)
            audit(if (prev == null) "DAY_CLOSED" else "DAY_CLOSING_UPDATED", "daily_closing", date,
                "cash diff ${Fmt.rupees(c.cashDiff)}, upi diff ${Fmt.rupees(c.upiDiff)}")
            c
        }
    }

    // ===================== Reports =====================
    suspend fun rangeReport(from: String, to: String): RangeReport {
        val exp = dao.expenseTotals(from, to)
        val ent = dao.entryTotals(from, to)
        return RangeReport(
            from = from, to = to, summary = dao.summary(from, to), cancelled = dao.cancelSummary(from, to),
            cashExpenses = exp.of("CASH"), upiExpenses = exp.of("UPI"),
            cashRefunds = ent.of(EntryType.REFUND_CASH), upiRefunds = ent.of(EntryType.REFUND_UPI),
            topItems = dao.topItems(from, to), categories = dao.categorySales(from, to),
            hours = dao.hourSales(from, to), closings = dao.closingsBetween(from, to),
        )
    }

    fun observeRange(from: String, to: String) =
        observe("bills", "bill_items", "expenses", "cash_entries", "daily_closing") { rangeReport(from, to) }

    suspend fun auditLog() = dao.recentAudit()

    suspend fun logSystem(action: String, details: String) = audit(action, "system", "-", details)
}
