package com.soumohotel.pos.print

import com.soumohotel.pos.data.Bill
import com.soumohotel.pos.data.BillItem
import com.soumohotel.pos.util.Fmt
import com.soumohotel.pos.util.Mode
import com.soumohotel.pos.util.Settings
import java.io.ByteArrayOutputStream

/** One line of a thermal receipt. align: 0 left, 1 centre, 2 right */
data class RLine(val text: String, val align: Int = 0, val bold: Boolean = false, val big: Boolean = false)

/**
 * The receipt is described once as [RLine]s and rendered two ways:
 * ESC/POS bytes for the Bluetooth printer, or a monospace PDF for sharing.
 * "Rs." is used instead of ₹ because most thermal printers cannot print the ₹ glyph.
 */
object Receipt {
    private fun lr(l: String, r: String, cols: Int): String {
        val room = cols - r.length - 1
        val left = if (l.length > room) l.take(room.coerceAtLeast(0)) else l
        return left + " ".repeat((cols - left.length - r.length).coerceAtLeast(1)) + r
    }

    fun lines(b: Bill, items: List<BillItem>, s: Settings, cols: Int): List<RLine> {
        val out = mutableListOf<RLine>()
        val dash = "-".repeat(cols)
        val bigOk = s.shopName.length <= cols / 2
        out += RLine(s.shopName, 1, bold = true, big = bigOk)
        if (s.address.isNotBlank()) s.address.chunked(cols).forEach { out += RLine(it, 1) }
        if (s.phone.isNotBlank()) out += RLine("Ph: ${s.phone}", 1)
        out += RLine(dash)
        if (b.status == "CANCELLED") out += RLine("*** CANCELLED ***", 1, bold = true)
        out += RLine("Bill No: ${b.billNo}")
        out += RLine("Date: ${Fmt.dateTime(b.createdAt)}")
        if (!b.customerName.isNullOrBlank()) out += RLine("Customer: ${b.customerName}")
        if (!b.customerPhone.isNullOrBlank()) out += RLine("Phone: ${b.customerPhone}")
        out += RLine(dash)
        out += RLine(lr("Item", "Amount", cols), bold = true)
        out += RLine(dash)
        for (it in items) {
            it.name.chunked(cols).forEach { part -> out += RLine(part) }
            out += RLine(lr("  ${it.qty} x ${Fmt.plain(it.rate)}", Fmt.plain(it.total), cols))
        }
        out += RLine(dash)
        if (b.discount > 0) {
            out += RLine(lr("Subtotal", Fmt.plain(b.subtotal), cols))
            out += RLine(lr("Discount", "-" + Fmt.plain(b.discount), cols))
        }
        out += RLine(lr("TOTAL (Rs.)", Fmt.plain(b.total), cols), bold = true)
        out += RLine(dash)
        out += RLine("Payment: ${Mode.label(b.paymentMode)}")
        if (b.paymentMode == Mode.SPLIT) {
            out += RLine(lr("  Cash", Fmt.plain(b.cashPaid), cols))
            out += RLine(lr("  UPI", Fmt.plain(b.upiPaid), cols))
        }
        out += RLine(dash)
        if (s.thankYou.isNotBlank()) s.thankYou.chunked(cols).forEach { out += RLine(it, 1) }
        return out
    }

    fun toEscPos(lines: List<RLine>, cols: Int): ByteArray {
        val o = ByteArrayOutputStream()
        fun w(vararg b: Int) = o.write(ByteArray(b.size) { b[it].toByte() })
        w(0x1B, '@'.code) // initialise
        for (l in lines) {
            w(0x1B, 'a'.code, l.align)
            w(0x1B, 'E'.code, if (l.bold) 1 else 0)
            w(0x1D, '!'.code, if (l.big) 0x11 else 0)
            o.write(ascii(l.text))
            o.write('\n'.code)
        }
        w(0x1D, '!'.code, 0)
        w(0x1B, 'E'.code, 0)
        w(0x1B, 'a'.code, 0)
        w(0x1B, 'd'.code, 4) // feed 4 lines
        w(0x1D, 'V'.code, 66, 0) // partial cut (ignored by printers without a cutter)
        return o.toByteArray()
    }

    /** Printable ASCII only: anything else would print as garbage on cheap printers. */
    fun ascii(s: String): ByteArray =
        s.replace("₹", "Rs.").map { if (it.code in 32..126) it else '?' }.joinToString("").toByteArray(Charsets.US_ASCII)

    /** Printer self-test page. */
    fun testPage(s: Settings, cols: Int): ByteArray = toEscPos(
        listOf(
            RLine(s.shopName, 1, bold = true),
            RLine("Printer test OK", 1),
            RLine("-".repeat(cols)),
            RLine("Paper: ${s.paper} mm  ($cols chars)"),
            RLine("0123456789".repeat(cols / 10 + 1).take(cols)),
            RLine("Rs. 1,234.50  Thank you", 1),
        ), cols
    )
}
