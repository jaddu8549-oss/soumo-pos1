package com.soumohotel.pos.util

import java.math.BigDecimal
import java.math.RoundingMode
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

object Fmt {
    val IST: ZoneId = ZoneId.of("Asia/Kolkata")
    private val dtFmt = DateTimeFormatter.ofPattern("dd/MM/yyyy hh:mm a", Locale.ENGLISH)
    private val dFmt = DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.ENGLISH)

    fun dateTime(ms: Long): String = Instant.ofEpochMilli(ms).atZone(IST).format(dtFmt)
    fun businessDate(ms: Long): String = Instant.ofEpochMilli(ms).atZone(IST).toLocalDate().toString()
    fun today(): String = businessDate(System.currentTimeMillis())
    fun todayDate(): LocalDate = LocalDate.now(IST)
    fun displayDate(iso: String): String = runCatching { LocalDate.parse(iso).format(dFmt) }.getOrDefault(iso)

    /** dd/MM/yyyy -> yyyy-MM-dd, or null */
    fun parseUserDate(s: String): String? =
        runCatching { LocalDate.parse(s.trim(), dFmt).toString() }.getOrNull()

    /** 123456789 -> 12,34,56,789 (Indian grouping) */
    fun indian(n: Long): String {
        val s = n.toString()
        if (s.length <= 3) return s
        val last3 = s.takeLast(3)
        val rest = s.dropLast(3).reversed().chunked(2).joinToString(",").reversed()
        return "$rest,$last3"
    }

    /** paise -> "₹1,234" or "₹1,234.50" */
    fun rupees(paise: Long, symbol: String = "₹"): String {
        val neg = paise < 0
        val a = kotlin.math.abs(paise)
        val r = a / 100
        val f = a % 100
        val body = indian(r) + if (f != 0L) String.format(Locale.US, ".%02d", f) else ""
        return (if (neg) "-" else "") + symbol + body
    }

    /** always two decimals, for receipts: 80.00 */
    fun plain(paise: Long): String {
        val neg = paise < 0
        val a = kotlin.math.abs(paise)
        return (if (neg) "-" else "") + String.format(Locale.US, "%d.%02d", a / 100, a % 100)
    }

    /** for pre-filling text boxes: "180" or "180.5" */
    fun input(paise: Long): String {
        if (paise <= 0) return ""
        return if (paise % 100 == 0L) (paise / 100).toString() else plain(paise).trimEnd('0')
    }

    /** "12.50" -> 1250 ; null if invalid or negative */
    fun parseMoney(s: String): Long? {
        val t = s.trim().replace(",", "")
        if (t.isEmpty()) return null
        return try {
            val p = BigDecimal(t).setScale(2, RoundingMode.HALF_UP).movePointRight(2).longValueExact()
            if (p < 0) null else p
        } catch (e: Exception) {
            null
        }
    }
}
