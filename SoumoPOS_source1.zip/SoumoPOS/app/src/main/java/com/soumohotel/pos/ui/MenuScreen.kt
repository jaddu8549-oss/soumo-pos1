@file:OptIn(ExperimentalMaterial3Api::class)

package com.soumohotel.pos.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.soumohotel.pos.AppViewModel
import com.soumohotel.pos.data.FoodItem
import com.soumohotel.pos.util.Fmt
import kotlinx.coroutines.launch

@Composable
fun MenuScreen(vm: AppViewModel) {
    val foods by vm.foods.collectAsState()
    val cats by vm.categories.collectAsState()
    var q by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf<Long?>(null) }
    var editing by remember { mutableStateOf<FoodItem?>(null) }
    var showForm by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<FoodItem?>(null) }
    val catName = cats.associate { it.id to it.name }
    val shown = foods.filter { (cat == null || it.categoryId == cat) && it.name.contains(q, true) }

    Page("Food Menu") {
        OutlinedTextField(
            q, { q = it }, singleLine = true, label = { Text("Search food") },
            leadingIcon = { Icon(Icons.Filled.Search, null) }, modifier = Modifier.fillMaxWidth().padding(12.dp),
        )
        LazyRow(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item { FilterChip(cat == null, { cat = null }, { Text("All") }) }
            items(cats) { c -> FilterChip(cat == c.id, { cat = c.id }, { Text(c.name) }) }
        }
        LazyColumn(Modifier.weight(1f).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (shown.isEmpty()) item { Text("No items. Tap “Add item”.") }
            items(shown, key = { it.id }) { f ->
                Card(Modifier.fillMaxWidth().clickable { editing = f; showForm = true }) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (f.imagePath != null) FoodImage(f.imagePath, Modifier.size(52.dp).clip(RoundedCornerShape(8.dp)))
                        Column(Modifier.weight(1f).padding(start = if (f.imagePath != null) 10.dp else 0.dp)) {
                            Text(f.name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                            Text("${catName[f.categoryId] ?: ""} · ${Fmt.rupees(f.price)}", fontSize = 13.sp)
                        }
                        Switch(f.available, { vm.setAvailable(f, it) })
                    }
                }
            }
            item { Column(Modifier.padding(32.dp)) {} }
        }
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.End) {
            ExtendedFloatingActionButton(onClick = { editing = null; showForm = true }, icon = { Icon(Icons.Filled.Add, null) }, text = { Text("Add item") })
        }
    }

    if (showForm) FoodForm(
        vm = vm, existing = editing, onDismiss = { showForm = false },
        onDelete = { deleting = editing; showForm = false },
    )
    deleting?.let { f ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Remove ${f.name}?") },
            text = { Text("It will disappear from the menu. Past bills keep their original name and price.") },
            confirmButton = { TextButton({ vm.deleteFood(f); deleting = null }) { Text("Remove", color = Red) } },
            dismissButton = { TextButton({ deleting = null }) { Text("Keep") } },
        )
    }
}

@Composable
private fun FoodForm(vm: AppViewModel, existing: FoodItem?, onDismiss: () -> Unit, onDelete: () -> Unit) {
    val cats by vm.categories.collectAsState()
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var price by remember { mutableStateOf(existing?.let { Fmt.input(it.price) } ?: "") }
    var catId by remember { mutableStateOf(existing?.categoryId ?: cats.firstOrNull()?.id ?: 0L) }
    var available by remember { mutableStateOf(existing?.available ?: true) }
    var image by remember { mutableStateOf(existing?.imagePath) }
    var newCat by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch { image = vm.importImage(uri) ?: image }
    }
    val catNames = cats.map { it.name }
    val selectedName = cats.firstOrNull { it.id == catId }?.name ?: ""

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Add food item" else "Edit food item") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                TextField1("Item name", name, { name = it }, Modifier.fillMaxWidth())
                MoneyField("Selling price", price, { price = it }, Modifier.fillMaxWidth())
                Dropdown("Category", catNames, selectedName, { n -> cats.firstOrNull { it.name == n }?.let { catId = it.id } }, Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(newCat, { newCat = it }, label = { Text("New category") }, singleLine = true, modifier = Modifier.weight(1f))
                    TextButton({ if (newCat.isNotBlank()) { vm.addCategory(newCat); newCat = "" } }) { Text("Add") }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Available for sale", Modifier.weight(1f)); Switch(available, { available = it })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (image != null) FoodImage(image, Modifier.size(48.dp).clip(RoundedCornerShape(8.dp)))
                    OutlinedButton({ picker.launch("image/*") }, Modifier.padding(start = 8.dp)) { Text(if (image == null) "Add photo (optional)" else "Change photo") }
                }
                if (existing != null) TextButton(onDelete) { Text("Remove from menu", color = Red) }
            }
        },
        confirmButton = {
            TextButton({
                val p = Fmt.parseMoney(price)
                if (p == null) vm.toast("Enter a valid price")
                else vm.saveFood(existing, name, catId, p, available, image) { onDismiss() }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } },
    )
}
