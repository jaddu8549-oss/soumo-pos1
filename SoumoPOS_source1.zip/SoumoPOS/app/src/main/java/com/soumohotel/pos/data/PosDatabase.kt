package com.soumohotel.pos.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        Category::class, FoodItem::class, Bill::class, BillItem::class, Expense::class,
        CashEntry::class, DayOpening::class, DailyClosing::class, AuditLog::class,
    ],
    version = 1,
    exportSchema = false,
)
abstract class PosDatabase : RoomDatabase() {
    abstract fun dao(): PosDao

    companion object {
        const val NAME = "soumo_pos.db"

        @Volatile
        private var instance: PosDatabase? = null

        fun get(context: Context): PosDatabase =
            instance ?: synchronized(this) {
                instance ?: build(context.applicationContext).also { instance = it }
            }

        fun closeAndReset() {
            synchronized(this) {
                instance?.close()
                instance = null
            }
        }

        private fun build(context: Context): PosDatabase =
            Room.databaseBuilder(context, PosDatabase::class.java, NAME)
                // TRUNCATE journal = the whole database is a single file, so backup is a clean file copy.
                .setJournalMode(RoomDatabase.JournalMode.TRUNCATE)
                .addCallback(object : RoomDatabase.Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        listOf(
                            "Breakfast", "Lunch", "Dinner", "Rolls", "Paratha",
                            "Snacks", "Beverages", "Special Items",
                        ).forEachIndexed { i, n ->
                            db.execSQL("INSERT INTO categories(name, sortOrder) VALUES('$n', $i)")
                        }
                    }
                })
                .build()
    }
}
