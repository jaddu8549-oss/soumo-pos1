package com.soumohotel.pos.print

import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import com.soumohotel.pos.data.Bill
import com.soumohotel.pos.data.BillItem
import com.soumohotel.pos.util.Fmt
import com.soumohotel.pos.util.Mode
import com.soumohotel.pos.util.Settings
import java.io.File

data class PdfLine(val left: String, val right: String = "", val bold: Boolean = false, val size: Float = 11f)

object Pdfs {
    private const val A4_W = 595
    private const val A4_H = 842

    /** Generic paginated A4 text document (reports, daily closing). */
    fun textDocument(file: File, lines: List<PdfLine>) {
        val doc = PdfDocument()
        val margin = 40f
        var pageNo = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(A4_W, A4_H, pageNo).create())
        var y = 50f
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        for (l in lines) {
            p.textSize = l.size
            p.typeface = if (l.bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            val lh = l.size * 1.55f
            if (y + lh > A4_H - 40) {
                doc.finishPage(page)
                pageNo++
                page = doc.startPage(PdfDocument.PageInfo.Builder(A4_W, A4_H, pageNo).create())
                y = 50f
            }
            val c = page.canvas
            p.textAlign = Paint.Align.LEFT
            c.drawText(l.left, margin, y, p)
            if (l.right.isNotEmpty()) {
                p.textAlign = Paint.Align.RIGHT
                c.drawText(l.right, A4_W - margin, y, p)
            }
            y += lh
        }
        doc.finishPage(page)
        file.outputStream().use { doc.writeTo(it) }
        doc.close()
    }

    /** Clean A4 invoice. */
    fun billA4(file: File, b: Bill, items: List<BillItem>, s: Settings) {
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(A4_W, A4_H, 1).create())
        val c = page.canvas
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val m = 40f
        val r = A4_W - m
        var y = 60f
        fun text(t: String, x: Float, size: Float, bold: Boolean = false, align: Paint.Align = Paint.Align.LEFT, color: Int = Color.BLACK) {
            p.textSize = size; p.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            p.textAlign = align; p.color = color
            c.drawText(t, x, y, p)
        }
        text(s.shopName, A4_W / 2f, 26f, true, Paint.Align.CENTER, Color.rgb(194, 65, 12)); y += 20
        if (s.address.isNotBlank()) { text(s.address, A4_W / 2f, 11f, align = Paint.Align.CENTER); y += 15 }
        if (s.phone.isNotBlank()) { text("Ph: ${s.phone}", A4_W / 2f, 11f, align = Paint.Align.CENTER); y += 15 }
        y += 10
        p.color = Color.LTGRAY; c.drawLine(m, y, r, y, p); y += 24
        text("Bill No: ${b.billNo}", m, 13f, true)
        text(Fmt.dateTime(b.createdAt), r, 13f, align = Paint.Align.RIGHT); y += 20
        if (!b.customerName.isNullOrBlank() || !b.customerPhone.isNullOrBlank()) {
            text("Customer: ${listOfNotNull(b.customerName, b.customerPhone).joinToString("  ")}", m, 12f); y += 20
        }
        if (b.status == "CANCELLED") { text("CANCELLED — ${b.cancelReason ?: ""}", m, 14f, true, color = Color.RED); y += 22 }
        y += 6
        p.color = Color.rgb(255, 237, 213); p.style = Paint.Style.FILL
        c.drawRect(m, y - 15, r, y + 8, p)
        text("Item", m + 6, 12f, true)
        text("Qty", 330f, 12f, true, Paint.Align.RIGHT)
        text("Rate", 430f, 12f, true, Paint.Align.RIGHT)
        text("Total", r - 6, 12f, true, Paint.Align.RIGHT)
        y += 26
        for (it in items) {
            text(it.name.take(40), m + 6, 12f)
            text(it.qty.toString(), 330f, 12f, align = Paint.Align.RIGHT)
            text(Fmt.rupees(it.rate), 430f, 12f, align = Paint.Align.RIGHT)
            text(Fmt.rupees(it.total), r - 6, 12f, align = Paint.Align.RIGHT)
            y += 20
        }
        p.color = Color.LTGRAY; c.drawLine(m, y - 6, r, y - 6, p); y += 14
        if (b.discount > 0) {
            text("Subtotal", 430f, 12f, align = Paint.Align.RIGHT); text(Fmt.rupees(b.subtotal), r - 6, 12f, align = Paint.Align.RIGHT); y += 18
            text("Discount", 430f, 12f, align = Paint.Align.RIGHT); text("-" + Fmt.rupees(b.discount), r - 6, 12f, align = Paint.Align.RIGHT); y += 18
        }
        text("TOTAL", 430f, 15f, true, Paint.Align.RIGHT); text(Fmt.rupees(b.total), r - 6, 15f, true, Paint.Align.RIGHT); y += 28
        text("Payment: ${Mode.label(b.paymentMode)}" +
            if (b.paymentMode == Mode.SPLIT) "  (Cash ${Fmt.rupees(b.cashPaid)} + UPI ${Fmt.rupees(b.upiPaid)})" else "", m, 12f)
        y += 40
        if (s.thankYou.isNotBlank()) text(s.thankYou, A4_W / 2f, 13f, align = Paint.Align.CENTER)
        doc.finishPage(page)
        file.outputStream().use { doc.writeTo(it) }
        doc.close()
    }

    /** Narrow receipt PDF (58 mm / 80 mm) using the same lines as the thermal printout. */
    fun billThermal(file: File, lines: List<RLine>, cols: Int, widthPt: Int) {
        val margin = 8f
        val charW = (widthPt - 2 * margin) / cols
        val size = charW / 0.6f
        val lh = size * 1.35f
        val height = (lines.size * lh + 2 * margin + 20).toInt()
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(widthPt, height, 1).create())
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        var y = margin + size
        for (l in lines) {
            val big = l.big
            p.typeface = if (l.bold) Typeface.create(Typeface.MONOSPACE, Typeface.BOLD) else Typeface.MONOSPACE
            p.textSize = if (big) size * 2 else size
            val w = p.measureText(l.text)
            val x = when (l.align) { 1 -> (widthPt - w) / 2f; 2 -> widthPt - margin - w; else -> margin }
            page.canvas.drawText(l.text.replace("₹", "Rs."), x, y, p)
            y += if (big) lh * 2 else lh
        }
        doc.finishPage(page)
        file.outputStream().use { doc.writeTo(it) }
        doc.close()
    }
}
