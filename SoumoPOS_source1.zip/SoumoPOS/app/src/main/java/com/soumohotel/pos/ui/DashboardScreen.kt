package com.soumohotel.pos.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.soumohotel.pos.AppViewModel
import com.soumohotel.pos.util.Fmt

@Composable
fun DashboardScreen(vm: AppViewModel, nav: NavController) {
    val date = remember { Fmt.today() }
    val f by remember { vm.repo.observeDay(date) }.collectAsState(null)
    val week by remember { vm.repo.observeLastDays(7) }.collectAsState(emptyList())
    val hours by remember { vm.repo.observeHours(date) }.collectAsState(emptyList())
    val shop by vm.settings.collectAsState()

    Page(shop.shopName) {
        Body {
            Text("Today · ${Fmt.displayDate(date)}", style = MaterialTheme.typography.titleMedium)
            val d = f
            if (d == null) { Text("Loading…"); return@Body }
            val m = Modifier.weight(1f)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("Total sales", Fmt.rupees(d.totalSales), m)
                StatCard("Bills · Avg", "${d.bills} · ${Fmt.rupees(d.avgBill)}", m)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("Cash sales", Fmt.rupees(d.cashSales), m, MaterialTheme.colorScheme.secondaryContainer, MaterialTheme.colorScheme.onSecondaryContainer)
                StatCard("UPI sales", Fmt.rupees(d.upiSales), m, MaterialTheme.colorScheme.tertiaryContainer, MaterialTheme.colorScheme.onTertiaryContainer)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("Net cash expected", Fmt.rupees(d.expectedCash), m, MaterialTheme.colorScheme.secondaryContainer, MaterialTheme.colorScheme.onSecondaryContainer)
                StatCard("Net UPI expected", Fmt.rupees(d.expectedUpi), m, MaterialTheme.colorScheme.tertiaryContainer, MaterialTheme.colorScheme.onTertiaryContainer)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("Expenses today", Fmt.rupees(d.totalExpenses), m, MaterialTheme.colorScheme.errorContainer, MaterialTheme.colorScheme.onErrorContainer)
                StatCard("Opening cash", Fmt.rupees(d.opening), m)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("Cash received (other)", Fmt.rupees(d.otherCashIn), m)
                StatCard("Cash withdrawn", Fmt.rupees(d.withdrawals), m)
            }
            if (d.closing != null) Text("✔ Day closed", color = Green)

            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    SectionTitle("Last 7 days sales")
                    BarChart(week.map { it.name }, week.map { it.amount })
                }
            }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    SectionTitle("Today by hour")
                    if (hours.isEmpty()) Text("No sales yet today") else
                        BarChart(hours.map { "%02d".format(it.hour) }, hours.map { it.amount }, barColor = Green)
                }
            }
        }
    }
}
