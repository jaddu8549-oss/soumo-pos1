package com.soumohotel.pos.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.soumohotel.pos.AppViewModel
import com.soumohotel.pos.util.Fmt

val ExpenseCategories = listOf(
    "Vegetable purchase", "Chicken purchase", "Grocery / Raw material", "Gas cylinder",
    "Staff expenses", "Electricity", "Rent", "Miscellaneous",
)

@Composable
fun ExpensesScreen(vm: AppViewModel, nav: NavController) {
    var date by remember { mutableStateOf(Fmt.today()) }
    var name by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var method by remember { mutableStateOf("CASH") }
    var cat by remember { mutableStateOf(ExpenseCategories[0]) }
    var remarks by remember { mutableStateOf("") }
    val list by remember(date) { vm.repo.observeExpenses(date) }.collectAsState(emptyList())

    Page("Expenses", onBack = { nav.popBackStack() }) {
        Body {
            SectionTitle("New expense (saved with current date & time)")
            Dropdown("Category", ExpenseCategories, cat, { cat = it; if (name.isBlank()) name = it }, Modifier.fillMaxWidth())
            TextField1("Expense name", name, { name = it }, Modifier.fillMaxWidth())
            MoneyField("Amount", amount, { amount = it }, Modifier.fillMaxWidth())
            ChoiceRow(listOf("Paid by Cash" to "CASH", "Paid by UPI" to "UPI"), method, { method = it })
            TextField1("Remarks (optional)", remarks, { remarks = it }, Modifier.fillMaxWidth())
            Button(
                onClick = {
                    val a = Fmt.parseMoney(amount)
                    if (a == null) vm.toast("Enter a valid amount")
                    else vm.addExpense(name.ifBlank { cat }, a, method, cat, remarks) { name = ""; amount = ""; remarks = "" }
                },
                modifier = Modifier.fillMaxWidth().height(54.dp),
            ) { Text("Save expense", fontSize = 16.sp) }

            SectionTitle("Expenses list")
            DateField("Date", date, { date = it })
            val active = list.filter { !it.voided }
            Text("Total: ${Fmt.rupees(active.sumOf { it.amount })}  (Cash ${Fmt.rupees(active.filter { it.method == "CASH" }.sumOf { it.amount })} · UPI ${Fmt.rupees(active.filter { it.method == "UPI" }.sumOf { it.amount })})", fontWeight = FontWeight.Bold)
            if (list.isEmpty()) Text("No expenses on this date")
            list.forEach { e ->
                Card(
                    Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = if (e.voided) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface),
                ) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(e.name + if (e.voided) "  (VOIDED)" else "", fontWeight = FontWeight.SemiBold)
                            Text("${e.category} · ${e.method} · ${Fmt.dateTime(e.createdAt)}", fontSize = 12.sp)
                            e.remarks?.let { Text(it, fontSize = 12.sp) }
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(Fmt.rupees(e.amount), fontWeight = FontWeight.Bold)
                            if (!e.voided) TextButton({ vm.voidExpense(e.id) }) { Text("Void", color = Red) }
                        }
                    }
                }
            }
        }
    }
}
