package com.soumohotel.pos

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.soumohotel.pos.data.FoodItem
import com.soumohotel.pos.data.RangeReport
import com.soumohotel.pos.data.Repository
import com.soumohotel.pos.print.BtPrinter
import com.soumohotel.pos.print.Docs
import com.soumohotel.pos.print.Pdfs
import com.soumohotel.pos.print.Receipt
import com.soumohotel.pos.util.AppPrefs
import com.soumohotel.pos.util.Backup
import com.soumohotel.pos.util.CartLine
import com.soumohotel.pos.util.Fmt
import com.soumohotel.pos.util.Settings
import com.soumohotel.pos.util.Share
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx = app.applicationContext
    val repo = Repository(ctx)
    val prefs = AppPrefs(ctx)
    val settings = MutableStateFlow(prefs.load())
    val messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    fun toast(s: String) { messages.tryEmit(s) }

    val categories = repo.dao.categories().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val foods = repo.dao.foods().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** Set after a successful restore: the app must be reopened to load the restored data. */
    val restartNeeded = MutableStateFlow(false)

    init {
        viewModelScope.launch(Dispatchers.IO) { Backup.autoDaily(ctx, prefs) }
    }

    // ===================== cart =====================
    val cart = mutableStateListOf<CartLine>()

    fun addToCart(f: FoodItem, categoryName: String) {
        val i = cart.indexOfFirst { it.foodId == f.id }
        if (i >= 0) cart[i] = cart[i].copy(qty = cart[i].qty + 1)
        else cart.add(CartLine(f.id, f.name, categoryName, f.price, 1))
    }

    fun changeQty(i: Int, delta: Int) {
        if (i !in cart.indices) return
        val q = cart[i].qty + delta
        if (q <= 0) cart.removeAt(i) else cart[i] = cart[i].copy(qty = q)
    }

    fun removeLine(i: Int) { if (i in cart.indices) cart.removeAt(i) }
    fun clearCart() = cart.clear()

    fun saveBill(
        discount: Long, mode: String, cash: Long, upi: Long, name: String, phone: String,
        print: Boolean, onSaved: (Long) -> Unit,
    ) {
        viewModelScope.launch {
            val lines = cart.toList()
            repo.createBill(lines, discount, mode, cash, upi, name, phone)
                .onSuccess { id ->
                    clearCart()
                    onSaved(id)
                    if (print || settings.value.autoPrint) printBill(id)
                }
                .onFailure { toast(it.message ?: "Could not save the bill") }
        }
    }

    fun cancelBill(id: Long, reason: String) = viewModelScope.launch {
        repo.cancelBill(id, reason).onSuccess { toast("Bill cancelled") }.onFailure { toast(it.message ?: "Failed") }
    }

    // ===================== printing & sharing =====================
    fun printBill(id: Long) {
        viewModelScope.launch {
            val s = settings.value
            if (s.paper == "A4") { shareBillPdf(id, false); return@launch }
            if (s.printerMac.isBlank()) { toast("Choose a Bluetooth printer in Settings first"); return@launch }
            val (b, items) = repo.billWithItems(id) ?: return@launch
            val cols = if (s.paper == "58") 32 else 48
            val data = Receipt.toEscPos(Receipt.lines(b, items, s, cols), cols)
            toast("Printing…")
            BtPrinter.send(ctx, s.printerMac, data)
                .onSuccess { toast("Sent to printer") }
                .onFailure { toast("Print failed: ${it.message}") }
        }
    }

    fun testPrint() {
        viewModelScope.launch {
            val s = settings.value
            val cols = if (s.paper == "58") 32 else 48
            toast("Sending test page…")
            BtPrinter.send(ctx, s.printerMac, Receipt.testPage(s, cols))
                .onSuccess { toast("Test page sent") }
                .onFailure { toast("Test failed: ${it.message}") }
        }
    }

    fun shareBillPdf(id: Long, whatsapp: Boolean) {
        viewModelScope.launch {
            val (b, items) = repo.billWithItems(id) ?: return@launch
            val s = settings.value
            val file = withContext(Dispatchers.IO) {
                val f = File(ctx.cacheDir, "${b.billNo}.pdf")
                when (s.paper) {
                    "58" -> Pdfs.billThermal(f, Receipt.lines(b, items, s, 32), 32, 164)
                    "80" -> Pdfs.billThermal(f, Receipt.lines(b, items, s, 48), 48, 227)
                    else -> Pdfs.billA4(f, b, items, s)
                }
                f
            }
            Share.file(ctx, file, "application/pdf", whatsapp, b.customerPhone)
        }
    }

    // ===================== menu =====================
    fun saveFood(existing: FoodItem?, name: String, catId: Long, price: Long, available: Boolean, image: String?, done: () -> Unit) {
        viewModelScope.launch {
            repo.saveFood(existing, name, catId, price, available, image)
                .onSuccess { done() }.onFailure { toast(it.message ?: "Could not save") }
        }
    }

    fun setAvailable(f: FoodItem, on: Boolean) = viewModelScope.launch { repo.setAvailable(f, on) }
    fun deleteFood(f: FoodItem) = viewModelScope.launch { repo.deactivateFood(f); toast("${f.name} removed from menu (old bills unchanged)") }
    fun addCategory(n: String) = viewModelScope.launch { repo.addCategory(n).onFailure { toast(it.message ?: "Failed") } }

    /** Copies a picked image into app storage so it survives even if the original is deleted. */
    suspend fun importImage(uri: Uri): String? = withContext(Dispatchers.IO) {
        runCatching {
            val dir = File(ctx.filesDir, "images").also { it.mkdirs() }
            val f = File(dir, "img_${System.currentTimeMillis()}.jpg")
            ctx.contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { i.copyTo(it) } }
            f.path
        }.getOrNull()
    }

    // ===================== expenses & closing =====================
    fun addExpense(name: String, amount: Long, method: String, cat: String, remarks: String, done: () -> Unit) {
        viewModelScope.launch {
            repo.addExpense(name, amount, method, cat, remarks).onSuccess { toast("Expense saved"); done() }
                .onFailure { toast(it.message ?: "Failed") }
        }
    }

    fun voidExpense(id: Long) = viewModelScope.launch { repo.voidExpense(id); toast("Expense voided (kept in audit log)") }

    fun addEntry(type: String, amount: Long, note: String, done: () -> Unit) {
        viewModelScope.launch {
            repo.addEntry(type, amount, note).onSuccess { done() }.onFailure { toast(it.message ?: "Failed") }
        }
    }

    fun voidEntry(id: Long) = viewModelScope.launch { repo.voidEntry(id) }
    fun setOpening(date: String, amount: Long) = viewModelScope.launch { repo.setOpening(date, amount); toast("Opening cash saved") }

    fun closeDay(date: String, cash: Long, upi: Long, notes: String) {
        viewModelScope.launch {
            repo.closeDay(date, cash, upi, notes).onSuccess { toast("Day closed and saved") }
                .onFailure { toast(it.message ?: "Failed") }
        }
    }

    fun shareClosingPdf(date: String, actualCash: Long, actualUpi: Long, whatsapp: Boolean) {
        viewModelScope.launch {
            val f = repo.dayFigures(date)
            val file = withContext(Dispatchers.IO) {
                File(Backup.reportDir(ctx), "DailyClosing_${date}.pdf").also {
                    Pdfs.textDocument(it, Docs.closingPdf(f, settings.value.shopName, actualCash, actualUpi))
                }
            }
            Share.file(ctx, file, "application/pdf", whatsapp)
        }
    }

    fun exportReport(rep: RangeReport, csv: Boolean) {
        viewModelScope.launch {
            val shop = settings.value.shopName
            val file = withContext(Dispatchers.IO) {
                val name = "Report_${rep.from}_to_${rep.to}"
                if (csv) File(Backup.reportDir(ctx), "$name.csv").also { Docs.reportCsv(it, rep, shop) }
                else File(Backup.reportDir(ctx), "$name.pdf").also { Pdfs.textDocument(it, Docs.reportPdf(rep, shop)) }
            }
            Share.file(ctx, file, if (csv) "text/csv" else "application/pdf")
        }
    }

    // ===================== settings, PIN, backup =====================
    fun saveSettings(s: Settings) {
        prefs.save(s)
        settings.value = prefs.load()
    }

    fun setPin(pin: String) { prefs.setPin(pin); settings.value = prefs.load(); viewModelScope.launch { repo.logSystem("PIN_SET", "PIN lock enabled") } }
    fun clearPin() { prefs.clearPin(); settings.value = prefs.load(); viewModelScope.launch { repo.logSystem("PIN_REMOVED", "PIN lock disabled") } }
    fun checkPin(pin: String) = prefs.checkPin(pin)

    fun backupNow() {
        viewModelScope.launch {
            runCatching { withContext(Dispatchers.IO) { Backup.createLocal(ctx) } }
                .onSuccess { toast("Backup saved: ${it.name}") }
                .onFailure { toast("Backup failed: ${it.message}") }
        }
    }

    fun backupTo(uri: Uri) {
        viewModelScope.launch {
            runCatching { withContext(Dispatchers.IO) { Backup.exportTo(ctx, uri) } }
                .onSuccess { toast("Backup saved to the chosen location") }
                .onFailure { toast("Backup failed: ${it.message}") }
        }
    }

    fun restoreFrom(uri: Uri) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { Backup.restore(ctx, uri) }
                .onSuccess { restartNeeded.value = true }
                .onFailure { toast(it.message ?: "Restore failed") }
        }
    }

    fun localBackups(): List<File> = Backup.backupDir(ctx).listFiles()?.sortedByDescending { it.lastModified() }.orEmpty()
    fun backupFolder(): String = Backup.backupDir(ctx).path
    fun reportFolder(): String = Backup.reportDir(ctx).path

    fun restoreLocal(f: File) = restoreFrom(Share.uri(ctx, f))
}
