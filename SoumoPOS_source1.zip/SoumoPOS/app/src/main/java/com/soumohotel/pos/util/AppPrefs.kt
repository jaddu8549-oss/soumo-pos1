package com.soumohotel.pos.util

import android.content.Context
import java.security.MessageDigest
import java.security.SecureRandom

data class Settings(
    val shopName: String = "Soumo Hotel",
    val address: String = "",
    val phone: String = "",
    val thankYou: String = "Thank you! Visit again.",
    /** "58" | "80" | "A4" */
    val paper: String = "80",
    val printerMac: String = "",
    val printerName: String = "",
    val autoPrint: Boolean = false,
    val pinSet: Boolean = false,
)

class AppPrefs(context: Context) {
    private val sp = context.getSharedPreferences("soumo_prefs", Context.MODE_PRIVATE)

    fun load() = Settings(
        shopName = sp.getString("shopName", "Soumo Hotel") ?: "Soumo Hotel",
        address = sp.getString("address", "") ?: "",
        phone = sp.getString("phone", "") ?: "",
        thankYou = sp.getString("thankYou", "Thank you! Visit again.") ?: "",
        paper = sp.getString("paper", "80") ?: "80",
        printerMac = sp.getString("printerMac", "") ?: "",
        printerName = sp.getString("printerName", "") ?: "",
        autoPrint = sp.getBoolean("autoPrint", false),
        pinSet = sp.getString("pinHash", null) != null,
    )

    fun save(s: Settings) {
        sp.edit()
            .putString("shopName", s.shopName).putString("address", s.address)
            .putString("phone", s.phone).putString("thankYou", s.thankYou)
            .putString("paper", s.paper).putString("printerMac", s.printerMac)
            .putString("printerName", s.printerName).putBoolean("autoPrint", s.autoPrint)
            .apply()
    }

    var lastAutoBackup: String
        get() = sp.getString("lastAutoBackup", "") ?: ""
        set(v) = sp.edit().putString("lastAutoBackup", v).apply()

    // ---- PIN (salted SHA-256; stays on the device) ----
    private fun hash(pin: String, salt: String): String =
        MessageDigest.getInstance("SHA-256").digest((salt + pin).toByteArray())
            .joinToString("") { "%02x".format(it) }

    fun setPin(pin: String) {
        val salt = ByteArray(8).also { SecureRandom().nextBytes(it) }.joinToString("") { "%02x".format(it) }
        sp.edit().putString("pinSalt", salt).putString("pinHash", hash(pin, salt)).apply()
    }

    fun checkPin(pin: String): Boolean {
        val salt = sp.getString("pinSalt", null) ?: return true
        return sp.getString("pinHash", null) == hash(pin, salt)
    }

    fun clearPin() = sp.edit().remove("pinSalt").remove("pinHash").apply()
}
