package com.soumohotel.pos.util

object Mode {
    const val CASH = "CASH"
    const val UPI = "UPI"
    const val SPLIT = "SPLIT"
    fun label(m: String) = when (m) { CASH -> "Cash"; UPI -> "UPI"; else -> "Cash + UPI" }
}

data class CartLine(
    val foodId: Long,
    val name: String,
    val category: String,
    val rate: Long,
    val qty: Int,
) {
    val total: Long get() = rate * qty
}

/** Pure money logic with no Android dependencies, so it can be unit-tested on a normal JVM. */
object Calc {
    fun subtotal(lines: List<CartLine>): Long = lines.sumOf { it.rate * it.qty }

    /** Returns (cash, upi) or a failure explaining the mismatch. */
    fun resolvePayment(total: Long, mode: String, cash: Long, upi: Long): Result<Pair<Long, Long>> {
        if (total <= 0) return Result.failure(IllegalArgumentException("Bill total must be more than ₹0"))
        return when (mode) {
            Mode.CASH -> Result.success(total to 0L)
            Mode.UPI -> Result.success(0L to total)
            Mode.SPLIT -> when {
                cash < 0 || upi < 0 -> Result.failure(IllegalArgumentException("Amounts cannot be negative"))
                cash + upi != total -> Result.failure(
                    IllegalArgumentException(
                        "Cash + UPI (${Fmt.rupees(cash + upi)}) must equal the bill total (${Fmt.rupees(total)})"
                    )
                )
                else -> Result.success(cash to upi)
            }
            else -> Result.failure(IllegalArgumentException("Unknown payment mode"))
        }
    }

    /** Expected Closing Cash = Opening + Cash Sales + Other Cash Receipts - Cash Expenses - Cash Withdrawals - Cash Refunds */
    fun expectedCash(
        opening: Long, cashSales: Long, otherCashIn: Long,
        cashExpenses: Long, withdrawals: Long, cashRefunds: Long,
    ): Long = opening + cashSales + otherCashIn - cashExpenses - withdrawals - cashRefunds

    /** Expected UPI = UPI Sales + Other UPI Receipts - UPI Refunds - UPI-paid Expenses */
    fun expectedUpi(upiSales: Long, otherUpiIn: Long, upiRefunds: Long, upiExpenses: Long): Long =
        upiSales + otherUpiIn - upiRefunds - upiExpenses

    /** actual - expected: negative = shortage, positive = excess */
    fun diff(actual: Long, expected: Long): Long = actual - expected
}
