package com.soumohotel.pos

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.RestaurantMenu
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.text.KeyboardOptions
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.soumohotel.pos.ui.AuditScreen
import com.soumohotel.pos.ui.BillDetailScreen
import com.soumohotel.pos.ui.BillingScreen
import com.soumohotel.pos.ui.CheckoutScreen
import com.soumohotel.pos.ui.ClosingScreen
import com.soumohotel.pos.ui.DashboardScreen
import com.soumohotel.pos.ui.ExpensesScreen
import com.soumohotel.pos.ui.HistoryScreen
import com.soumohotel.pos.ui.MenuScreen
import com.soumohotel.pos.ui.MoreScreen
import com.soumohotel.pos.ui.PosTheme
import com.soumohotel.pos.ui.ReportsScreen
import com.soumohotel.pos.ui.SettingsScreen
import kotlin.system.exitProcess

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PosTheme { App(viewModel()) } }
    }
}

private data class Tab(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

@Composable
fun App(vm: AppViewModel) {
    val settings by vm.settings.collectAsState()
    val restart by vm.restartNeeded.collectAsState()
    var unlocked by remember { mutableStateOf(false) }

    if (restart) {
        AlertDialog(
            onDismissRequest = {},
            title = { Text("Restore complete") },
            text = { Text("Your data has been restored. The app will now close; open it again to see the restored data.") },
            confirmButton = { Button(onClick = { exitProcess(0) }) { Text("Close app") } },
        )
        return
    }
    if (settings.pinSet && !unlocked) {
        LockScreen(vm) { unlocked = true }
        return
    }

    val nav = rememberNavController()
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(Unit) { vm.messages.collect { snack.showSnackbar(it) } }
    val tabs = listOf(
        Tab("dashboard", "Home", Icons.Filled.Home),
        Tab("bill", "New Bill", Icons.Filled.ShoppingCart),
        Tab("menu", "Menu", Icons.Filled.RestaurantMenu),
        Tab("history", "Bills", Icons.Filled.Receipt),
        Tab("more", "More", Icons.Filled.MoreHoriz),
    )
    val current = nav.currentBackStackEntryAsState().value?.destination?.route

    Scaffold(
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            NavigationBar {
                tabs.forEach { t ->
                    NavigationBarItem(
                        selected = current == t.route,
                        onClick = {
                            nav.navigate(t.route) {
                                popUpToRoute(nav)
                                launchSingleTop = true
                            }
                        },
                        icon = { Icon(t.icon, t.label) },
                        label = { Text(t.label) },
                    )
                }
            }
        },
    ) { pad ->
        NavHost(nav, startDestination = "dashboard", modifier = Modifier.padding(pad)) {
            composable("dashboard") { DashboardScreen(vm, nav) }
            composable("bill") { BillingScreen(vm, nav) }
            composable("checkout") { CheckoutScreen(vm, nav) }
            composable("menu") { MenuScreen(vm) }
            composable("history") { HistoryScreen(vm, nav) }
            composable("more") { MoreScreen(nav) }
            composable("expenses") { ExpensesScreen(vm, nav) }
            composable("reports") { ReportsScreen(vm, nav) }
            composable("closing") { ClosingScreen(vm, nav) }
            composable("settings") { SettingsScreen(vm, nav) { unlocked = false } }
            composable("audit") { AuditScreen(vm, nav) }
            composable("bill/{id}", listOf(navArgument("id") { type = NavType.LongType })) {
                BillDetailScreen(vm, nav, it.arguments!!.getLong("id"))
            }
        }
    }
}

private fun androidx.navigation.NavOptionsBuilder.popUpToRoute(nav: androidx.navigation.NavController) {
    popUpTo(nav.graph.startDestinationId) { saveState = false }
}

@Composable
fun LockScreen(vm: AppViewModel, onUnlock: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Soumo POS", style = androidx.compose.material3.MaterialTheme.typography.headlineMedium)
        Text("Enter PIN", modifier = Modifier.padding(vertical = 12.dp))
        OutlinedTextField(
            value = pin,
            onValueChange = { s ->
                if (s.length <= 8 && s.all { it.isDigit() }) {
                    pin = s; wrong = false
                    if (s.length >= 4 && vm.checkPin(s)) onUnlock()
                }
            },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            singleLine = true, isError = wrong, label = { Text("PIN") },
        )
        Button(onClick = { if (vm.checkPin(pin)) onUnlock() else { wrong = true; pin = "" } }, modifier = Modifier.padding(top = 12.dp)) { Text("Unlock") }
        if (wrong) Text("Wrong PIN", color = androidx.compose.material3.MaterialTheme.colorScheme.error)
    }
}
