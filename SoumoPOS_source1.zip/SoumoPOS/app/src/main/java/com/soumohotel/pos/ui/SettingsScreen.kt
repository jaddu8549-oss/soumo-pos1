package com.soumohotel.pos.ui

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.soumohotel.pos.AppViewModel
import com.soumohotel.pos.print.BtDevice
import com.soumohotel.pos.print.BtPrinter
import com.soumohotel.pos.util.Fmt
import java.io.File

@Composable
fun MoreScreen(nav: NavController) {
    Page("More") {
        Body {
            listOf(
                Triple("Expenses", "expenses", Icons.Filled.ShoppingCart),
                Triple("Daily Closing", "closing", Icons.Filled.AccountBalanceWallet),
                Triple("Reports", "reports", Icons.Filled.BarChart),
                Triple("Settings, Printer & Backup", "settings", Icons.Filled.Settings),
            ).forEach { (label, route, icon) ->
                Card(Modifier.fillMaxWidth().clickable { nav.navigate(route) }) {
                    Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(icon, null, tint = Orange)
                        Text(label, Modifier.weight(1f).padding(start = 14.dp), fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null)
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: AppViewModel, nav: NavController, onLockNow: () -> Unit) {
    val ctx = LocalContext.current
    val s by vm.settings.collectAsState()
    var shop by remember(s) { mutableStateOf(s.shopName) }
    var addr by remember(s) { mutableStateOf(s.address) }
    var phone by remember(s) { mutableStateOf(s.phone) }
    var thanks by remember(s) { mutableStateOf(s.thankYou) }

    var devices by remember { mutableStateOf<List<BtDevice>>(emptyList()) }
    var showDevices by remember { mutableStateOf(false) }
    var pinDialog by remember { mutableStateOf(false) }
    var restoreConfirm by remember { mutableStateOf<(() -> Unit)?>(null) }
    var showLocal by remember { mutableStateOf(false) }

    fun loadDevices() {
        devices = BtPrinter.pairedDevices(ctx)
        showDevices = true
        if (devices.isEmpty()) vm.toast("No paired printers. Pair it first in Android Bluetooth settings.")
    }
    val btPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) loadDevices() else vm.toast("Bluetooth permission is needed to print")
    }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri -> uri?.let { vm.backupTo(it) } }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) restoreConfirm = { vm.restoreFrom(uri) }
    }

    Page("Settings", onBack = { nav.popBackStack() }) {
        Body {
            SectionTitle("Business details (printed on bills)")
            TextField1("Business name", shop, { shop = it }, Modifier.fillMaxWidth())
            TextField1("Address", addr, { addr = it }, Modifier.fillMaxWidth())
            TextField1("Phone", phone, { phone = it }, Modifier.fillMaxWidth(), KeyboardType.Phone)
            TextField1("Thank-you message", thanks, { thanks = it }, Modifier.fillMaxWidth())
            Button({ vm.saveSettings(s.copy(shopName = shop.ifBlank { "Soumo Hotel" }, address = addr, phone = phone, thankYou = thanks)); vm.toast("Saved") }, Modifier.fillMaxWidth()) { Text("Save details") }

            SectionTitle("Bluetooth printer")
            Text("Paper / bill format")
            ChoiceRow(listOf("58 mm" to "58", "80 mm" to "80", "A4 (PDF)" to "A4"), s.paper, { vm.saveSettings(s.copy(paper = it)) })
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Text(if (s.printerMac.isBlank()) "No printer selected" else "Selected: ${s.printerName}", fontWeight = FontWeight.SemiBold)
                    if (s.printerMac.isNotBlank()) Text(s.printerMac, fontSize = 12.sp)
                }
            }
            Button({
                if (BtPrinter.hasPermission(ctx)) loadDevices() else btPermission.launch(Manifest.permission.BLUETOOTH_CONNECT)
            }, Modifier.fillMaxWidth()) { Text("Select / change printer") }
            OutlinedButton({ vm.testPrint() }, Modifier.fillMaxWidth(), enabled = s.printerMac.isNotBlank()) { Text("Print test page") }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Print automatically after saving a bill", Modifier.weight(1f))
                Switch(s.autoPrint, { vm.saveSettings(s.copy(autoPrint = it)) })
            }
            Text("First pair the printer in Android Settings › Bluetooth (PIN is usually 0000 or 1234), then select it here.", fontSize = 12.sp)

            SectionTitle("Security")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (s.pinSet) "PIN lock is ON" else "PIN lock is OFF", Modifier.weight(1f))
                OutlinedButton({ pinDialog = true }) { Text(if (s.pinSet) "Change / remove" else "Set PIN") }
            }
            if (s.pinSet) OutlinedButton(onLockNow, Modifier.fillMaxWidth()) { Text("Lock now") }
            OutlinedButton({ nav.navigate("audit") }, Modifier.fillMaxWidth()) { Text("View audit log") }

            SectionTitle("Backup & restore")
            Text("The app also makes an automatic backup once a day (last 7 kept).", fontSize = 12.sp)
            Button({ vm.backupNow() }, Modifier.fillMaxWidth()) { Text("Backup now (phone storage)") }
            OutlinedButton({ exportLauncher.launch("soumo_backup_${Fmt.today()}.db") }, Modifier.fillMaxWidth()) { Text("Save backup to another location / device") }
            OutlinedButton({ importLauncher.launch(arrayOf("*/*")) }, Modifier.fillMaxWidth()) { Text("Restore from a backup file") }
            OutlinedButton({ showLocal = true }, Modifier.fillMaxWidth()) { Text("Restore from on-phone backups") }
            Text("Backups folder:\n${vm.backupFolder()}", fontSize = 11.sp)
            Text("Reports folder:\n${vm.reportFolder()}", fontSize = 11.sp)
        }
    }

    if (showDevices && devices.isNotEmpty()) AlertDialog(
        onDismissRequest = { showDevices = false },
        title = { Text("Choose printer") },
        text = {
            LazyColumn {
                items(devices) { d ->
                    Column(Modifier.fillMaxWidth().clickable {
                        vm.saveSettings(s.copy(printerMac = d.mac, printerName = d.name)); showDevices = false
                    }.padding(vertical = 10.dp)) {
                        Text(d.name, fontWeight = FontWeight.SemiBold); Text(d.mac, fontSize = 12.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton({ showDevices = false }) { Text("Close") } },
    )

    if (pinDialog) {
        var pin by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { pinDialog = false },
            title = { Text("Set PIN (4–8 digits)") },
            text = {
                TextField1("New PIN", pin, { if (it.length <= 8 && it.all(Char::isDigit)) pin = it }, keyboard = KeyboardType.NumberPassword)
            },
            confirmButton = { TextButton({ if (pin.length >= 4) { vm.setPin(pin); pinDialog = false } else vm.toast("PIN must be at least 4 digits") }) { Text("Save PIN") } },
            dismissButton = {
                Row {
                    if (s.pinSet) TextButton({ vm.clearPin(); pinDialog = false }) { Text("Remove PIN", color = Red) }
                    TextButton({ pinDialog = false }) { Text("Cancel") }
                }
            },
        )
    }

    restoreConfirm?.let { go ->
        AlertDialog(
            onDismissRequest = { restoreConfirm = null },
            title = { Text("Restore backup?") },
            text = { Text("This replaces ALL current data with the backup. Your current data is saved first as a “before_restore” backup, so you can undo this.") },
            confirmButton = { TextButton({ restoreConfirm = null; go() }) { Text("Restore", color = Red) } },
            dismissButton = { TextButton({ restoreConfirm = null }) { Text("Cancel") } },
        )
    }

    if (showLocal) {
        val files: List<File> = remember { vm.localBackups() }
        AlertDialog(
            onDismissRequest = { showLocal = false },
            title = { Text("On-phone backups") },
            text = {
                if (files.isEmpty()) Text("No backups yet.") else LazyColumn {
                    items(files) { f ->
                        Text(f.name, Modifier.fillMaxWidth().clickable { showLocal = false; restoreConfirm = { vm.restoreLocal(f) } }.padding(vertical = 10.dp), fontSize = 14.sp)
                    }
                }
            },
            confirmButton = { TextButton({ showLocal = false }) { Text("Close") } },
        )
    }
}

@Composable
fun AuditScreen(vm: AppViewModel, nav: NavController) {
    val log by produceState(emptyList<com.soumohotel.pos.data.AuditLog>()) { value = vm.repo.auditLog() }
    Page("Audit log", onBack = { nav.popBackStack() }) {
        LazyColumn(Modifier.weight(1f).padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            if (log.isEmpty()) item { Text("Nothing recorded yet") }
            items(log, key = { it.id }) { a ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(10.dp)) {
                        Text(a.action, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(a.details, fontSize = 13.sp)
                        Text(Fmt.dateTime(a.createdAt), fontSize = 11.sp)
                    }
                }
            }
        }
    }
}
