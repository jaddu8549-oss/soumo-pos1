@file:OptIn(ExperimentalMaterial3Api::class)

package com.soumohotel.pos.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.soumohotel.pos.AppViewModel
import com.soumohotel.pos.util.Calc
import com.soumohotel.pos.util.Fmt
import com.soumohotel.pos.util.Mode

// ===================== New Bill: pick items =====================
@Composable
fun BillingScreen(vm: AppViewModel, nav: NavController) {
    val foods by vm.foods.collectAsState()
    val cats by vm.categories.collectAsState()
    var q by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf<Long?>(null) }
    val catName = cats.associate { it.id to it.name }
    val shown = foods.filter { it.available && (cat == null || it.categoryId == cat) && it.name.contains(q, ignoreCase = true) }

    Page("New Bill") {
        OutlinedTextField(
            q, { q = it }, singleLine = true, label = { Text("Search items") },
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
        )
        LazyRow(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item { FilterChip(cat == null, { cat = null }, { Text("All") }) }
            items(cats) { c -> FilterChip(cat == c.id, { cat = c.id }, { Text(c.name) }) }
        }
        if (foods.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("No menu items yet.\nAdd them in the Menu tab.", modifier = Modifier.padding(24.dp))
            }
        } else LazyVerticalGrid(
            GridCells.Fixed(2), Modifier.weight(1f).padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(shown, key = { it.id }) { f ->
                val inCart = vm.cart.firstOrNull { it.foodId == f.id }?.qty ?: 0
                Card(
                    Modifier.fillMaxWidth().height(96.dp).clickable { vm.addToCart(f, catName[f.categoryId] ?: "") },
                    colors = CardDefaults.cardColors(containerColor = if (inCart > 0) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(2.dp),
                ) {
                    Column(Modifier.padding(10.dp).fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                        Text(f.name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, maxLines = 2)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(Fmt.rupees(f.price), color = Orange, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            if (inCart > 0) Text("× $inCart", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
        if (vm.cart.isNotEmpty()) {
            val total = Calc.subtotal(vm.cart.toList())
            Button(
                onClick = { nav.navigate("checkout") },
                modifier = Modifier.fillMaxWidth().padding(12.dp).height(56.dp),
            ) { Text("View bill · ${vm.cart.sumOf { it.qty }} items · ${Fmt.rupees(total)}", fontSize = 17.sp) }
        }
    }
}

// ===================== Checkout =====================
@Composable
fun CheckoutScreen(vm: AppViewModel, nav: NavController) {
    var discountTxt by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf(Mode.CASH) }
    var cashTxt by remember { mutableStateOf("") }
    var upiTxt by remember { mutableStateOf("") }

    val lines = vm.cart.toList()
    val sub = Calc.subtotal(lines)
    val discount = Fmt.parseMoney(discountTxt) ?: 0L
    val total = sub - discount
    val cash = Fmt.parseMoney(cashTxt) ?: 0L
    val upi = Fmt.parseMoney(upiTxt) ?: 0L
    val payment = Calc.resolvePayment(total, mode, cash, upi)
    val discountOk = discount in 0..sub
    val canSave = lines.isNotEmpty() && discountOk && payment.isSuccess

    fun save(print: Boolean) = vm.saveBill(discount, mode, cash, upi, name, phone, print) { id ->
        nav.navigate("bill/$id") { popUpTo("bill") }
    }

    Page("Bill", onBack = { nav.popBackStack() }) {
        Body {
            if (lines.isEmpty()) { Text("The bill is empty."); return@Body }
            lines.forEachIndexed { i, l ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(l.name, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                            Text("${Fmt.rupees(l.rate)} each", fontSize = 12.sp)
                        }
                        IconButton({ vm.changeQty(i, -1) }, Modifier.size(44.dp)) { Icon(Icons.Filled.Remove, "Less") }
                        Text("${l.qty}", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        IconButton({ vm.changeQty(i, 1) }, Modifier.size(44.dp)) { Icon(Icons.Filled.Add, "More") }
                        Text(Fmt.rupees(l.total), Modifier.padding(horizontal = 6.dp), fontWeight = FontWeight.Bold)
                        IconButton({ vm.removeLine(i) }) { Icon(Icons.Filled.Delete, "Remove", tint = Red) }
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MoneyField("Discount", discountTxt, { discountTxt = it }, Modifier.weight(1f))
            }
            if (!discountOk) Text("Discount cannot be more than the subtotal", color = Red)

            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    RowKV("Subtotal", Fmt.rupees(sub))
                    if (discount > 0) RowKV("Discount", "-" + Fmt.rupees(discount))
                    RowKV("TOTAL", Fmt.rupees(total.coerceAtLeast(0)), bold = true)
                }
            }

            SectionTitle("Payment")
            ChoiceRow(listOf("Cash" to Mode.CASH, "UPI" to Mode.UPI, "Cash + UPI" to Mode.SPLIT), mode, { mode = it })
            if (mode == Mode.SPLIT) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MoneyField("Cash", cashTxt, {
                        cashTxt = it
                        upiTxt = Fmt.input((total - (Fmt.parseMoney(it) ?: 0L)).coerceAtLeast(0))
                    }, Modifier.weight(1f))
                    MoneyField("UPI", upiTxt, { upiTxt = it }, Modifier.weight(1f))
                }
                payment.exceptionOrNull()?.let { Text(it.message ?: "", color = Red) }
                if (payment.isSuccess) Text("✔ Cash + UPI matches the bill total", color = Green)
            }

            SectionTitle("Customer (optional)")
            TextField1("Name", name, { name = it }, Modifier.fillMaxWidth())
            TextField1("Phone (for WhatsApp)", phone, { phone = it }, Modifier.fillMaxWidth(), KeyboardType.Phone)

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                OutlinedButton({ save(false) }, enabled = canSave, modifier = Modifier.weight(1f).height(56.dp)) { Text("Save") }
                Button({ save(true) }, enabled = canSave, modifier = Modifier.weight(1.4f).height(56.dp)) {
                    Icon(Icons.Filled.Print, null); Text("  Save & Print", fontSize = 16.sp)
                }
            }
        }
    }
}

// ===================== Bill detail =====================
@Composable
fun BillDetailScreen(vm: AppViewModel, nav: NavController, id: Long) {
    val data by remember(id) { vm.repo.observeBill(id) }.collectAsState(null)
    var cancelDialog by remember { mutableStateOf(false) }
    var reason by remember { mutableStateOf("") }

    Page("Bill details", onBack = { nav.popBackStack() }) {
        val d = data
        if (d == null) { Text("Loading…", Modifier.padding(16.dp)); return@Page }
        val (b, items) = d
        Body {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Text(b.billNo, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(Fmt.dateTime(b.createdAt))
                    if (!b.customerName.isNullOrBlank() || !b.customerPhone.isNullOrBlank())
                        Text("Customer: " + listOfNotNull(b.customerName, b.customerPhone).joinToString(" · "))
                    if (b.status == "CANCELLED") {
                        Text("CANCELLED — ${b.cancelReason}", color = Red, fontWeight = FontWeight.Bold)
                        b.cancelledAt?.let { Text("on ${Fmt.dateTime(it)}", color = Red, fontSize = 12.sp) }
                    }
                }
            }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    items.forEach {
                        RowKV("${it.name}  ${it.qty} × ${Fmt.rupees(it.rate)}", Fmt.rupees(it.total))
                    }
                    if (b.discount > 0) {
                        RowKV("Subtotal", Fmt.rupees(b.subtotal)); RowKV("Discount", "-" + Fmt.rupees(b.discount))
                    }
                    RowKV("TOTAL", Fmt.rupees(b.total), bold = true)
                }
            }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    RowKV("Payment mode", Mode.label(b.paymentMode))
                    RowKV("Cash received", Fmt.rupees(b.cashPaid))
                    RowKV("UPI received", Fmt.rupees(b.upiPaid))
                    RowKV("Status", if (b.status == "CANCELLED") "CANCELLED" else b.paymentStatus)
                }
            }
            Button({ vm.printBill(id) }, Modifier.fillMaxWidth().height(54.dp)) { Icon(Icons.Filled.Print, null); Text("  Print (Bluetooth)", fontSize = 16.sp) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton({ vm.shareBillPdf(id, false) }, Modifier.weight(1f).height(50.dp)) { Icon(Icons.Filled.Share, null); Text("  PDF") }
                FilledTonalButton({ vm.shareBillPdf(id, true) }, Modifier.weight(1f).height(50.dp)) { Icon(Icons.Filled.Share, null); Text("  WhatsApp") }
            }
            if (b.status == "ACTIVE") {
                OutlinedButton({ cancelDialog = true }, Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = Red)) { Text("Cancel this bill") }
            }
            OutlinedButton({ nav.navigate("bill") { popUpTo("bill") { inclusive = true } } }, Modifier.fillMaxWidth().height(50.dp)) { Text("New bill") }
        }
    }
    if (cancelDialog) AlertDialog(
        onDismissRequest = { cancelDialog = false },
        title = { Text("Cancel bill?") },
        text = {
            Column {
                Text("The bill stays in history marked CANCELLED and is removed from sales totals.")
                OutlinedTextField(reason, { reason = it }, label = { Text("Reason (required)") }, modifier = Modifier.padding(top = 8.dp))
            }
        },
        confirmButton = {
            TextButton({ if (reason.isNotBlank()) { vm.cancelBill(id, reason); cancelDialog = false; reason = "" } }) { Text("Cancel bill", color = Red) }
        },
        dismissButton = { TextButton({ cancelDialog = false }) { Text("Keep") } },
    )
}

// ===================== History =====================
@Composable
fun HistoryScreen(vm: AppViewModel, nav: NavController) {
    var q by remember { mutableStateOf("") }
    val bills by remember(q) { vm.repo.observeBills(q) }.collectAsState(emptyList())
    Page("Bill history") {
        OutlinedTextField(
            q, { q = it }, singleLine = true, label = { Text("Bill no, date (dd/mm/yyyy), name, phone") },
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            modifier = Modifier.fillMaxWidth().padding(12.dp),
        )
        LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (bills.isEmpty()) item { Text("No bills found") }
            items(bills, key = { it.id }) { b ->
                val cancelled = b.status == "CANCELLED"
                Card(
                    Modifier.fillMaxWidth().clickable { nav.navigate("bill/${b.id}") },
                    colors = CardDefaults.cardColors(containerColor = if (cancelled) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surface),
                ) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(b.billNo, fontWeight = FontWeight.Bold)
                            Text(Fmt.dateTime(b.createdAt), fontSize = 12.sp)
                            Text(Mode.label(b.paymentMode) + if (cancelled) " · CANCELLED" else "", fontSize = 12.sp, color = if (cancelled) Red else Color.Unspecified)
                        }
                        Text(Fmt.rupees(b.total), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                }
            }
        }
    }
}
