package com.soumohotel.pos.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.soumohotel.pos.AppViewModel
import com.soumohotel.pos.util.Fmt
import java.time.DayOfWeek
import java.time.temporal.TemporalAdjusters

@Composable
fun ReportsScreen(vm: AppViewModel, nav: NavController) {
    var range by remember { mutableStateOf("TODAY") }
    var from by remember { mutableStateOf(Fmt.today()) }
    var to by remember { mutableStateOf(Fmt.today()) }

    val today = Fmt.todayDate()
    val (f, t) = when (range) {
        "TODAY" -> today.toString() to today.toString()
        "WEEK" -> today.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)).toString() to today.toString()
        "MONTH" -> today.withDayOfMonth(1).toString() to today.toString()
        else -> (if (from <= to) from else to) to (if (from <= to) to else from)
    }
    val rep by remember(f, t) { vm.repo.observeRange(f, t) }.collectAsState(null)

    Page("Reports", onBack = { nav.popBackStack() }) {
        Body {
            ChoiceRow(listOf("Today" to "TODAY", "Week" to "WEEK", "Month" to "MONTH", "Custom" to "CUSTOM"), range, { range = it })
            if (range == "CUSTOM") Row {
                DateField("From", from, { from = it }, Modifier.weight(1f))
                DateField("To", to, { to = it }, Modifier.weight(1f))
            }
            Text("${Fmt.displayDate(f)} – ${Fmt.displayDate(t)}", style = MaterialTheme.typography.titleSmall)
            val r = rep ?: run { Text("Loading…"); return@Body }
            val s = r.summary

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("Total sales", Fmt.rupees(s.total), Modifier.weight(1f))
                StatCard("Bills · Avg", "${s.bills} · ${Fmt.rupees(r.avgBill)}", Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("Cash", Fmt.rupees(s.cash), Modifier.weight(1f), MaterialTheme.colorScheme.secondaryContainer, MaterialTheme.colorScheme.onSecondaryContainer)
                StatCard("UPI", Fmt.rupees(s.upi), Modifier.weight(1f), MaterialTheme.colorScheme.tertiaryContainer, MaterialTheme.colorScheme.onTertiaryContainer)
            }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    RowKV("Total expenses", Fmt.rupees(r.totalExpenses))
                    RowKV("   Cash / UPI", "${Fmt.rupees(r.cashExpenses)} / ${Fmt.rupees(r.upiExpenses)}")
                    RowKV("Discounts given", Fmt.rupees(s.discount))
                    RowKV("Refunds", Fmt.rupees(r.totalRefunds))
                    RowKV("Cancelled bills", "${r.cancelled.count} (${Fmt.rupees(r.cancelled.amount)})")
                }
            }
            SectionTitle("Most sold items")
            r.topItems.forEach { RowKV("${it.name}  ×${it.qty}", Fmt.rupees(it.amount)) }
            if (r.topItems.isEmpty()) Text("No sales in this period")
            SectionTitle("Category-wise sales")
            r.categories.forEach { RowKV(it.name, Fmt.rupees(it.amount)) }
            SectionTitle("Hour-wise sales")
            if (r.hours.isNotEmpty()) BarChart(r.hours.map { "%02d".format(it.hour) }, r.hours.map { it.amount }, barColor = Green)
            SectionTitle("Daily closing differences")
            if (r.closings.isEmpty()) Text("No closed days in this period")
            r.closings.forEach {
                RowKV(Fmt.displayDate(it.businessDate), "Cash ${Fmt.rupees(it.cashDiff)} · UPI ${Fmt.rupees(it.upiDiff)}",
                    color = if (it.cashDiff == 0L && it.upiDiff == 0L) Green else Red)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                Button({ vm.exportReport(r, false) }, Modifier.weight(1f)) { Text("Export PDF") }
                OutlinedButton({ vm.exportReport(r, true) }, Modifier.weight(1f)) { Text("Excel / CSV") }
            }
            Text("The CSV file opens directly in Excel.", style = MaterialTheme.typography.bodySmall)
        }
    }
}
