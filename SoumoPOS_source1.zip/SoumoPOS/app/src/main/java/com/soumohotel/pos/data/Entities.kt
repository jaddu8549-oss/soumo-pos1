package com.soumohotel.pos.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/** All money values are stored as Long paise (₹1 = 100) to avoid floating-point errors. */

@Entity(tableName = "categories", indices = [Index(value = ["name"], unique = true)])
data class Category(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val sortOrder: Int = 0,
)

@Entity(
    tableName = "food_items",
    foreignKeys = [ForeignKey(entity = Category::class, parentColumns = ["id"], childColumns = ["categoryId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index("categoryId")],
)
data class FoodItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val categoryId: Long,
    val price: Long,
    val available: Boolean = true,
    /** false = "deleted" (soft delete). Old bills keep their own copy of name/price. */
    val active: Boolean = true,
    val imagePath: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
)

@Entity(
    tableName = "bills",
    indices = [Index(value = ["billNo"], unique = true), Index("businessDate"), Index("createdAt")],
)
data class Bill(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val billNo: String,
    val createdAt: Long,
    /** yyyy-MM-dd in Asia/Kolkata */
    val businessDate: String,
    val subtotal: Long,
    val discount: Long,
    val total: Long,
    val cashPaid: Long,
    val upiPaid: Long,
    /** CASH | UPI | SPLIT */
    val paymentMode: String,
    /** PAID (a bill is only ever saved when cash + upi == total) */
    val paymentStatus: String = "PAID",
    val customerName: String? = null,
    val customerPhone: String? = null,
    /** ACTIVE | CANCELLED  (cancelled bills are never deleted) */
    val status: String = "ACTIVE",
    val cancelReason: String? = null,
    val cancelledAt: Long? = null,
)

/** Snapshot of the item at billing time: later menu/price edits never change old bills. */
@Entity(
    tableName = "bill_items",
    foreignKeys = [ForeignKey(entity = Bill::class, parentColumns = ["id"], childColumns = ["billId"])],
    indices = [Index("billId")],
)
data class BillItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val billId: Long,
    val foodItemId: Long,
    val name: String,
    val categoryName: String,
    val qty: Int,
    val rate: Long,
    val total: Long,
)

@Entity(tableName = "expenses", indices = [Index("businessDate")])
data class Expense(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val amount: Long,
    /** CASH | UPI */
    val method: String,
    val category: String,
    val remarks: String? = null,
    val createdAt: Long,
    val businessDate: String,
    val voided: Boolean = false,
)

/** Other cash/UPI movements: CASH_IN, CASH_WITHDRAWAL, UPI_IN, REFUND_CASH, REFUND_UPI */
@Entity(tableName = "cash_entries", indices = [Index("businessDate")])
data class CashEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String,
    val amount: Long,
    val note: String? = null,
    val createdAt: Long,
    val businessDate: String,
    val voided: Boolean = false,
)

@Entity(tableName = "day_opening")
data class DayOpening(
    @PrimaryKey val businessDate: String,
    val openingCash: Long,
)

@Entity(tableName = "daily_closing")
data class DailyClosing(
    @PrimaryKey val businessDate: String,
    val openingCash: Long,
    val expectedCash: Long,
    val actualCash: Long,
    val cashDiff: Long,
    val expectedUpi: Long,
    val actualUpi: Long,
    val upiDiff: Long,
    val totalSales: Long,
    val totalBills: Int,
    val totalExpenses: Long,
    val totalRefunds: Long,
    val notes: String? = null,
    val closedAt: Long,
)

@Entity(tableName = "audit_log", indices = [Index("createdAt")])
data class AuditLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val action: String,
    val entity: String,
    val entityId: String,
    val details: String,
    val createdAt: Long = System.currentTimeMillis(),
)

// ---- query result holders ----
data class SalesSummary(val bills: Int, val total: Long, val cash: Long, val upi: Long, val discount: Long)
data class CancelSummary(val count: Int, val amount: Long)
data class MethodTotal(val method: String, val amount: Long)
data class TypeTotal(val type: String, val amount: Long)
data class NameAmt(val name: String, val qty: Long, val amount: Long)
data class HourAmt(val hour: Int, val bills: Int, val amount: Long)
