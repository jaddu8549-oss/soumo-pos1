package com.soumohotel.pos.print

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.util.UUID

data class BtDevice(val name: String, val mac: String)

/**
 * Classic Bluetooth (SPP / RFCOMM) printing for ESC/POS thermal printers.
 * Works fully offline: it talks directly to the paired printer, no internet or server.
 * The printer must first be paired once in Android's Bluetooth settings.
 */
object BtPrinter {
    private val SPP: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val lock = Mutex() // one print job at a time

    fun needsRuntimePermission() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

    fun hasPermission(ctx: Context): Boolean =
        !needsRuntimePermission() ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    private fun adapter(ctx: Context): BluetoothAdapter? =
        (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    fun isEnabled(ctx: Context): Boolean = adapter(ctx)?.isEnabled == true

    @SuppressLint("MissingPermission")
    fun pairedDevices(ctx: Context): List<BtDevice> {
        if (!hasPermission(ctx)) return emptyList()
        return runCatching {
            adapter(ctx)?.bondedDevices.orEmpty()
                .map { BtDevice(it.name ?: it.address, it.address) }
                .sortedBy { it.name.lowercase() }
        }.getOrDefault(emptyList())
    }

    @SuppressLint("MissingPermission")
    suspend fun send(ctx: Context, mac: String, data: ByteArray): Result<Unit> = withContext(Dispatchers.IO) {
        lock.withLock {
            runCatching {
                if (mac.isBlank()) error("No printer selected. Choose one in Settings > Printer.")
                if (!hasPermission(ctx)) error("Bluetooth permission is missing. Allow it in Settings > Printer.")
                val ad = adapter(ctx) ?: error("This phone has no Bluetooth.")
                if (!ad.isEnabled) error("Bluetooth is turned off. Turn it on and try again.")
                val device = ad.getRemoteDevice(mac)
                ad.cancelDiscovery() // discovery slows down / breaks connections

                var socket: BluetoothSocket? = null
                try {
                    socket = device.createRfcommSocketToServiceRecord(SPP)
                    try {
                        socket.connect()
                    } catch (first: Exception) {
                        // Many cheap printers only accept the fallback RFCOMM channel 1.
                        runCatching { socket?.close() }
                        socket = device.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
                            .invoke(device, 1) as BluetoothSocket
                        socket.connect()
                    }
                    val out = socket.outputStream
                    var i = 0
                    while (i < data.size) { // small chunks: printer buffers are tiny
                        val n = minOf(512, data.size - i)
                        out.write(data, i, n)
                        out.flush()
                        i += n
                        Thread.sleep(40)
                    }
                    Thread.sleep(600) // let the printer finish receiving before the link closes
                } finally {
                    runCatching { socket?.close() }
                }
            }.recoverCatching {
                throw IllegalStateException(
                    it.message?.takeIf { m -> m.length > 3 && !m.contains("read failed") }
                        ?: "Could not reach the printer. Check it is switched on, in range and paired."
                )
            }
        }
    }
}
