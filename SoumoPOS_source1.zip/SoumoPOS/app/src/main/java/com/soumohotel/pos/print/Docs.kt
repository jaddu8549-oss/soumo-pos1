package com.soumohotel.pos.print

import com.soumohotel.pos.data.DayFigures
import com.soumohotel.pos.data.RangeReport
import com.soumohotel.pos.util.Fmt
import java.io.File

/** Builds the content of the daily-closing and range reports for PDF and CSV. */
object Docs {
    private fun h(t: String) = PdfLine(t, bold = true, size = 13f)
    private fun r(l: String, v: String, bold: Boolean = false) = PdfLine(l, v, bold)
    private val gap = PdfLine("", size = 6f)

    private fun diffText(d: Long) = when {
        d == 0L -> "Matched"
        d < 0 -> "SHORT by ${Fmt.rupees(-d)}"
        else -> "EXCESS ${Fmt.rupees(d)}"
    }

    fun closingPdf(f: DayFigures, shop: String, actualCash: Long, actualUpi: Long): List<PdfLine> {
        val cashDiff = actualCash - f.expectedCash
        val upiDiff = actualUpi - f.expectedUpi
        return listOf(
            PdfLine(shop, bold = true, size = 20f),
            PdfLine("Daily Closing Report — ${Fmt.displayDate(f.date)}", size = 13f),
            gap,
            h("Cash reconciliation"),
            r("Opening cash", Fmt.rupees(f.opening)),
            r("+ Cash sales", Fmt.rupees(f.cashSales)),
            r("+ Other cash received", Fmt.rupees(f.otherCashIn)),
            r("- Cash expenses", Fmt.rupees(f.cashExpenses)),
            r("- Cash withdrawals", Fmt.rupees(f.withdrawals)),
            r("- Cash refunds", Fmt.rupees(f.cashRefunds)),
            r("Expected closing cash", Fmt.rupees(f.expectedCash), true),
            r("Actual cash counted", Fmt.rupees(actualCash), true),
            r("Cash difference", diffText(cashDiff), true),
            gap,
            h("UPI reconciliation"),
            r("UPI sales", Fmt.rupees(f.upiSales)),
            r("+ Other UPI received", Fmt.rupees(f.otherUpiIn)),
            r("- UPI refunds", Fmt.rupees(f.upiRefunds)),
            r("- Expenses paid by UPI", Fmt.rupees(f.upiExpenses)),
            r("Expected UPI collection", Fmt.rupees(f.expectedUpi), true),
            r("Actual UPI collection", Fmt.rupees(actualUpi), true),
            r("UPI difference", diffText(upiDiff), true),
            gap,
            h("Summary"),
            r("Total sales", Fmt.rupees(f.totalSales)),
            r("Cash collection (sales)", Fmt.rupees(f.cashSales)),
            r("UPI collection (sales)", Fmt.rupees(f.upiSales)),
            r("Discounts given", Fmt.rupees(f.discount)),
            r("Total expenses", Fmt.rupees(f.totalExpenses)),
            r("Total refunds", Fmt.rupees(f.totalRefunds)),
            r("Total bills", f.bills.toString()),
            r("Cancelled bills", "${f.cancelledCount} (${Fmt.rupees(f.cancelledAmount)})"),
        )
    }

    fun reportPdf(rep: RangeReport, shop: String): List<PdfLine> {
        val s = rep.summary
        val out = mutableListOf(
            PdfLine(shop, bold = true, size = 20f),
            PdfLine("Sales Report: ${Fmt.displayDate(rep.from)} to ${Fmt.displayDate(rep.to)}", size = 13f),
            gap, h("Summary"),
            r("Total sales", Fmt.rupees(s.total), true),
            r("Cash sales", Fmt.rupees(s.cash)),
            r("UPI sales", Fmt.rupees(s.upi)),
            r("Discounts", Fmt.rupees(s.discount)),
            r("Number of bills", s.bills.toString()),
            r("Average bill value", Fmt.rupees(rep.avgBill)),
            r("Total expenses", Fmt.rupees(rep.totalExpenses)),
            r("   Cash expenses", Fmt.rupees(rep.cashExpenses)),
            r("   UPI expenses", Fmt.rupees(rep.upiExpenses)),
            r("Refunds", Fmt.rupees(rep.totalRefunds)),
            r("Cancelled bills", "${rep.cancelled.count} (${Fmt.rupees(rep.cancelled.amount)})"),
            gap, h("Payment-mode breakdown"),
            r("Cash", Fmt.rupees(s.cash)), r("UPI", Fmt.rupees(s.upi)),
            gap, h("Most sold items"),
        )
        rep.topItems.forEach { out += r("${it.name}  x${it.qty}", Fmt.rupees(it.amount)) }
        out += gap; out += h("Category-wise sales")
        rep.categories.forEach { out += r("${it.name}  (${it.qty} items)", Fmt.rupees(it.amount)) }
        out += gap; out += h("Hour-wise sales")
        rep.hours.forEach { out += r("%02d:00 - %02d:59  (${it.bills} bills)".format(it.hour, it.hour), Fmt.rupees(it.amount)) }
        out += gap; out += h("Daily closing differences")
        if (rep.closings.isEmpty()) out += PdfLine("No days closed in this period")
        rep.closings.forEach {
            out += r(Fmt.displayDate(it.businessDate) + "  cash: " + diffText(it.cashDiff), "UPI: " + diffText(it.upiDiff))
        }
        return out
    }

    private fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""

    /** CSV that opens directly in Excel (UTF-8 with BOM so ₹ and names show correctly). */
    fun reportCsv(file: File, rep: RangeReport, shop: String) {
        val s = rep.summary
        val rows = mutableListOf<List<String>>()
        fun p(v: Long) = Fmt.plain(v)
        rows += listOf(shop, "Report", rep.from, rep.to)
        rows += listOf("")
        rows += listOf("SUMMARY", "Value")
        rows += listOf("Total sales", p(s.total)); rows += listOf("Cash sales", p(s.cash)); rows += listOf("UPI sales", p(s.upi))
        rows += listOf("Discounts", p(s.discount)); rows += listOf("Bills", s.bills.toString()); rows += listOf("Average bill", p(rep.avgBill))
        rows += listOf("Cash expenses", p(rep.cashExpenses)); rows += listOf("UPI expenses", p(rep.upiExpenses))
        rows += listOf("Refunds", p(rep.totalRefunds)); rows += listOf("Cancelled bills", rep.cancelled.count.toString())
        rows += listOf("")
        rows += listOf("MOST SOLD ITEMS", "Qty", "Amount"); rep.topItems.forEach { rows += listOf(it.name, it.qty.toString(), p(it.amount)) }
        rows += listOf("")
        rows += listOf("CATEGORY SALES", "Qty", "Amount"); rep.categories.forEach { rows += listOf(it.name, it.qty.toString(), p(it.amount)) }
        rows += listOf("")
        rows += listOf("HOUR", "Bills", "Amount"); rep.hours.forEach { rows += listOf("%02d:00".format(it.hour), it.bills.toString(), p(it.amount)) }
        rows += listOf("")
        rows += listOf("DAILY CLOSING", "Expected cash", "Actual cash", "Cash diff", "Expected UPI", "Actual UPI", "UPI diff")
        rep.closings.forEach { rows += listOf(it.businessDate, p(it.expectedCash), p(it.actualCash), p(it.cashDiff), p(it.expectedUpi), p(it.actualUpi), p(it.upiDiff)) }
        file.writeText("﻿" + rows.joinToString("\r\n") { r -> r.joinToString(",") { q(it) } })
    }
}
