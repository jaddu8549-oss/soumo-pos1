package com.soumohotel.pos.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface PosDao {
    // ---- categories & menu ----
    @Query("SELECT * FROM categories ORDER BY sortOrder, name")
    fun categories(): Flow<List<Category>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertCategory(c: Category): Long

    @Query("SELECT * FROM food_items WHERE active = 1 ORDER BY name COLLATE NOCASE")
    fun foods(): Flow<List<FoodItem>>

    @Query("SELECT * FROM food_items WHERE id = :id")
    suspend fun food(id: Long): FoodItem?

    @Insert
    suspend fun insertFood(f: FoodItem): Long

    @Update
    suspend fun updateFood(f: FoodItem)

    // ---- bills ----
    @Insert
    suspend fun insertBill(b: Bill): Long

    @Insert
    suspend fun insertBillItems(items: List<BillItem>)

    @Query("SELECT COUNT(*) FROM bills WHERE businessDate = :date")
    suspend fun billCountForDate(date: String): Int

    @Query("SELECT * FROM bills WHERE id = :id")
    suspend fun bill(id: Long): Bill?

    @Query("SELECT * FROM bill_items WHERE billId = :billId ORDER BY id")
    suspend fun billItems(billId: Long): List<BillItem>

    @Query("UPDATE bills SET status = 'CANCELLED', cancelReason = :reason, cancelledAt = :at WHERE id = :id AND status = 'ACTIVE'")
    suspend fun cancelBill(id: Long, reason: String, at: Long): Int

    @Query("SELECT * FROM bills ORDER BY createdAt DESC LIMIT 500")
    suspend fun recentBills(): List<Bill>

    @Query(
        "SELECT * FROM bills WHERE billNo LIKE '%' || :q || '%' OR customerName LIKE '%' || :q || '%' " +
            "OR customerPhone LIKE '%' || :q || '%' OR businessDate = :isoDate ORDER BY createdAt DESC LIMIT 500"
    )
    suspend fun searchBills(q: String, isoDate: String): List<Bill>

    @Query("SELECT * FROM bills WHERE businessDate BETWEEN :from AND :to ORDER BY createdAt")
    suspend fun billsBetween(from: String, to: String): List<Bill>

    // ---- aggregates (ACTIVE bills only) ----
    @Query(
        "SELECT COUNT(*) AS bills, COALESCE(SUM(total),0) AS total, COALESCE(SUM(cashPaid),0) AS cash, " +
            "COALESCE(SUM(upiPaid),0) AS upi, COALESCE(SUM(discount),0) AS discount " +
            "FROM bills WHERE status = 'ACTIVE' AND businessDate BETWEEN :from AND :to"
    )
    suspend fun summary(from: String, to: String): SalesSummary

    @Query(
        "SELECT COUNT(*) AS count, COALESCE(SUM(total),0) AS amount FROM bills " +
            "WHERE status = 'CANCELLED' AND businessDate BETWEEN :from AND :to"
    )
    suspend fun cancelSummary(from: String, to: String): CancelSummary

    @Query(
        "SELECT bi.name AS name, SUM(bi.qty) AS qty, SUM(bi.total) AS amount FROM bill_items bi " +
            "JOIN bills b ON b.id = bi.billId WHERE b.status = 'ACTIVE' AND b.businessDate BETWEEN :from AND :to " +
            "GROUP BY bi.name ORDER BY qty DESC LIMIT 15"
    )
    suspend fun topItems(from: String, to: String): List<NameAmt>

    @Query(
        "SELECT bi.categoryName AS name, SUM(bi.qty) AS qty, SUM(bi.total) AS amount FROM bill_items bi " +
            "JOIN bills b ON b.id = bi.billId WHERE b.status = 'ACTIVE' AND b.businessDate BETWEEN :from AND :to " +
            "GROUP BY bi.categoryName ORDER BY amount DESC"
    )
    suspend fun categorySales(from: String, to: String): List<NameAmt>

    @Query(
        "SELECT CAST(strftime('%H', b.createdAt / 1000 + 19800, 'unixepoch') AS INTEGER) AS hour, " +
            "COUNT(*) AS bills, SUM(b.total) AS amount FROM bills b " +
            "WHERE b.status = 'ACTIVE' AND b.businessDate BETWEEN :from AND :to GROUP BY hour ORDER BY hour"
    )
    suspend fun hourSales(from: String, to: String): List<HourAmt>

    @Query(
        "SELECT businessDate AS name, COUNT(*) AS qty, SUM(total) AS amount FROM bills " +
            "WHERE status = 'ACTIVE' AND businessDate BETWEEN :from AND :to GROUP BY businessDate ORDER BY businessDate"
    )
    suspend fun dailySales(from: String, to: String): List<NameAmt>

    // ---- expenses & other entries ----
    @Insert
    suspend fun insertExpense(e: Expense): Long

    @Query("UPDATE expenses SET voided = 1 WHERE id = :id")
    suspend fun voidExpense(id: Long)

    @Query("SELECT * FROM expenses WHERE businessDate BETWEEN :from AND :to ORDER BY createdAt DESC")
    suspend fun expensesBetween(from: String, to: String): List<Expense>

    @Query("SELECT * FROM expenses WHERE id = :id")
    suspend fun expense(id: Long): Expense?

    @Query(
        "SELECT method, COALESCE(SUM(amount),0) AS amount FROM expenses " +
            "WHERE voided = 0 AND businessDate BETWEEN :from AND :to GROUP BY method"
    )
    suspend fun expenseTotals(from: String, to: String): List<MethodTotal>

    @Insert
    suspend fun insertEntry(e: CashEntry): Long

    @Query("UPDATE cash_entries SET voided = 1 WHERE id = :id")
    suspend fun voidEntry(id: Long)

    @Query("SELECT * FROM cash_entries WHERE id = :id")
    suspend fun entry(id: Long): CashEntry?

    @Query("SELECT * FROM cash_entries WHERE businessDate BETWEEN :from AND :to ORDER BY createdAt DESC")
    suspend fun entriesBetween(from: String, to: String): List<CashEntry>

    @Query(
        "SELECT type, COALESCE(SUM(amount),0) AS amount FROM cash_entries " +
            "WHERE voided = 0 AND businessDate BETWEEN :from AND :to GROUP BY type"
    )
    suspend fun entryTotals(from: String, to: String): List<TypeTotal>

    // ---- opening cash & closing ----
    @Query("SELECT * FROM day_opening WHERE businessDate = :date")
    suspend fun opening(date: String): DayOpening?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertOpening(o: DayOpening)

    @Query("SELECT * FROM daily_closing WHERE businessDate = :date")
    suspend fun closing(date: String): DailyClosing?

    @Query("SELECT * FROM daily_closing WHERE businessDate < :date ORDER BY businessDate DESC LIMIT 1")
    suspend fun lastClosingBefore(date: String): DailyClosing?

    @Query("SELECT * FROM daily_closing WHERE businessDate BETWEEN :from AND :to ORDER BY businessDate")
    suspend fun closingsBetween(from: String, to: String): List<DailyClosing>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertClosing(c: DailyClosing)

    // ---- audit ----
    @Insert
    suspend fun insertAudit(a: AuditLog)

    @Query("SELECT * FROM audit_log ORDER BY createdAt DESC, id DESC LIMIT 300")
    suspend fun recentAudit(): List<AuditLog>
}
